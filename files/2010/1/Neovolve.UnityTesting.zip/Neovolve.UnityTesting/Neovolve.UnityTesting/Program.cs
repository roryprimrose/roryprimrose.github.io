﻿using System;
using System.Configuration;
using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.Configuration;

namespace Neovolve.UnityTesting
{
    class Program
    {
        static void Main(string[] args)
        {
            UnityConfigurationSection section = (UnityConfigurationSection)ConfigurationManager.GetSection("unity");
            UnityContainer container = new UnityContainer();

            section.Containers.Default.Configure(container);

            CachedSomethingDone something = (CachedSomethingDone)container.Resolve<IDoSomething>();

            Console.WriteLine("Dependency configured with max age: " + something.MaxAgeInMilliseconds);
            Console.ReadKey();
        }
    }

    public interface IDoSomething
    {
        String Execute();
    }

    public class SomethingDone : IDoSomething
    {
        public String Execute()
        {
            return"Some random value";
        }
    }

    public class CachedSomethingDone : IDoSomething
    {
        private readonly IDoSomething _dependency;

        public CachedSomethingDone(IDoSomething dependency, Int64 maxAgeInMilliseconds)
        {
            _dependency = dependency;
            MaxAgeInMilliseconds = maxAgeInMilliseconds;
        }

        public String Execute()
        {
            // Check cache for value
            // If cache has value and is not too old then return the value
            // If not, get value from dependency, cache it for the next call and return the value

            return _dependency.Execute();
        }

        public long MaxAgeInMilliseconds
        {
            get;
            private set;
        }
    }
}