using System;
using System.ComponentModel;
using System.Configuration;
using System.Globalization;
using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.Configuration;

namespace Neovolve.UnityTesting
{
    public class AppSettingsParameterInjectionElement : InjectionParameterValueElement
    {
        public Object CreateInstance()
        {
            String configurationValue = ConfigurationManager.AppSettings[AppSettingKey];
            Type typeToCreate = TypeToCreate;

            if (typeToCreate == typeof(String))
            {
                return configurationValue;
            }

            TypeConverter converter = GetTypeConverter(typeToCreate, TypeConverterName, TypeResolver);

            try
            {
                return converter.ConvertFromString(configurationValue);
            }
            catch (NotSupportedException ex)
            {
                const String MessageFormat =
                    "The AppSetting with key '{0}' and value '{1}' cannot be converted to type '{2}'";
                String settingValue = configurationValue ?? "(null)";

                String failureMessage = String.Format(
                    CultureInfo.InvariantCulture, MessageFormat, AppSettingKey, settingValue, typeToCreate.FullName);
                
                throw new ConfigurationErrorsException(failureMessage, ex);
            }
        }

        public override InjectionParameterValue CreateParameterValue(Type targetType)
        {
            Type type;

            if (String.IsNullOrEmpty(TypeName))
            {
                type = targetType;
            }
            else
            {
                type = TypeResolver.ResolveType(TypeName);
            }

            return new InjectionParameter(type, CreateInstance());
        }

        private static TypeConverter GetTypeConverter(
            Type typeToCreate, String typeConverterName, UnityTypeResolver typeResolver)
        {
            if (!String.IsNullOrEmpty(typeConverterName))
            {
                return (TypeConverter)Activator.CreateInstance(typeResolver.ResolveType(typeConverterName));
            }

            return TypeDescriptor.GetConverter(typeToCreate);
        }

        [ConfigurationProperty("appSettingKey", IsRequired = true)]
        public String AppSettingKey
        {
            get
            {
                return (String)base["appSettingKey"];
            }

            set
            {
                base["appSettingKey"] = value;
            }
        }

        [ConfigurationProperty("typeConverter", IsRequired = false, DefaultValue = null)]
        public String TypeConverterName
        {
            get
            {
                return (String)base["typeConverter"];
            }

            set
            {
                base["typeConverter"] = value;
            }
        }

        [ConfigurationProperty("type", DefaultValue = null)]
        public String TypeName
        {
            get
            {
                return (String)base["type"];
            }

            set
            {
                base["type"] = value;
            }
        }

        public Type TypeToCreate
        {
            get
            {
                return TypeResolver.ResolveWithDefault(TypeName, typeof(String));
            }
        }
    }
}