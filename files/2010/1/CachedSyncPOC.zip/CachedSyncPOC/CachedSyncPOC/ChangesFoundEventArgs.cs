using System;
using System.Collections.Generic;

namespace CachedSyncPOC
{
    /// <summary>
    /// The changes found event args.
    /// </summary>
    internal class ChangesFoundEventArgs : EventArgs
    {
        /// <summary>
        /// Gets or sets Changes.
        /// </summary>
        /// <value>
        /// The changes.
        /// </value>
        public IList<ItemData> Changes
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets ReplicaId.
        /// </summary>
        /// <value>
        /// The replica id.
        /// </value>
        public Guid ReplicaId
        {
            get;
            set;
        }
    }
}