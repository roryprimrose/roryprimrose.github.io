﻿using System;

namespace CachedSyncPOC
{
    /// <summary>
    /// The <see cref="ItemData"/>
    /// class defines the data that participates in synchronization sessions.
    /// </summary>
    public class ItemData
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ItemData"/> class.
        /// </summary>
        public ItemData()
        {
            Id = Guid.NewGuid().ToString();
            Data = Guid.NewGuid().ToString();
        }

        /// <summary>
        /// Gets or sets the id.
        /// </summary>
        /// <value>The id of the item.</value>
        public String Id
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the data.
        /// </summary>
        /// <value>The data for the item.</value>
        public String Data
        {
            get;
            set;
        }
    }
}
