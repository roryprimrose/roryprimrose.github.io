using System;
using Microsoft.Synchronization;
using Microsoft.Synchronization.MetadataStorage;

namespace CachedSyncPOC
{
    /// <summary>
    /// The item data retriever.
    /// </summary>
    internal class ItemDataRetriever : IChangeDataRetriever
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ItemDataRetriever"/> class.
        /// </summary>
        /// <param name="metadata">
        /// The metadata.
        /// </param>
        public ItemDataRetriever(ReplicaMetadata metadata)
        {
            Metadata = metadata;
        }

        /// <summary>
        /// When overridden in a derived class, this method retrieves item data for a change.
        /// </summary>
        /// <param name="loadChangeContext">
        /// Metadata that describes the change for which data should be retrieved.
        /// </param>
        /// <returns>
        /// The item data for the change.
        /// </returns>
        public Object LoadChangeData(LoadChangeContext loadChangeContext)
        {
            SyncId changeId = loadChangeContext.ItemChange.ItemId;

            return LoadFromSyncId(changeId);
        }

        /// <summary>
        /// Loads from sync id.
        /// </summary>
        /// <param name="changeId">The change id.</param>
        /// <returns>A <see cref="Object"/> instance.</returns>
        public ItemData LoadFromSyncId(SyncId changeId)
        {
            ItemMetadata item = Metadata.FindItemMetadataById(changeId);

            return new ItemData
                       {
                           Id = item.GetStringField("Id"), 
                           Data = item.GetStringField("Data")
                       };
        }

        /// <summary>
        /// Gets the ID format schema of the provider.
        /// </summary>
        /// <value>
        /// The id formats.
        /// </value>
        /// <returns>
        /// The ID format schema of the provider.
        /// </returns>
        public SyncIdFormatGroup IdFormats
        {
            get
            {
                return Metadata.IdFormats;
            }
        }

        /// <summary>
        /// Gets or sets Metadata.
        /// </summary>
        /// <value>
        /// The metadata.
        /// </value>
        protected ReplicaMetadata Metadata
        {
            get;
            set;
        }
    }
}