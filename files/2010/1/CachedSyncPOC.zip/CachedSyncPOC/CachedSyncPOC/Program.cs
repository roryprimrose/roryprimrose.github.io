﻿using System;
using System.IO;
using Microsoft.Synchronization;

namespace CachedSyncPOC
{
    /// <summary>
    /// The program.
    /// </summary>
    internal class Program
    {
        /// <summary>
        /// Builds the metadata path.
        /// </summary>
        /// <param name="replicaId">
        /// The replica id.
        /// </param>
        /// <returns>
        /// A <see cref="String"/> instance.
        /// </returns>
        private static String BuildMetadataPath(Guid replicaId)
        {
            return Path.GetTempPath() + "\\" + replicaId + ".dat";
        }

        /// <summary>
        /// The main entry point.
        /// </summary>
        /// <param name="args">
        /// The arguments.
        /// </param>
        private static void Main(String[] args)
        {
            Guid remoteReplicaId = Guid.NewGuid();
            Guid localReplicaId = Guid.NewGuid();

            PopulateMetadata(localReplicaId, remoteReplicaId);

            try
            {
                // Preview all changes
                RunSync(localReplicaId, remoteReplicaId, true, null);

                ItemDataFilter filter = new ItemDataFilter("LocalSecondId");

                // Preview just the filtered item
                RunSync(localReplicaId, remoteReplicaId, true, filter);

                // Apply the change for the filtered item
                RunSync(localReplicaId, remoteReplicaId, false, filter);

                // Apply filter changes again and we shouldn't see anything applied
                RunSync(localReplicaId, remoteReplicaId, false, filter);

                // Apply all changes
                RunSync(localReplicaId, remoteReplicaId, false, null);

                // Apply all changes again and we shouldn't see anything applied
                RunSync(localReplicaId, remoteReplicaId, false, null);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            finally
            {
                String remoteMetadataPath = BuildMetadataPath(remoteReplicaId);
                String localMetadataPath = BuildMetadataPath(localReplicaId);

                File.Delete(localMetadataPath);
                File.Delete(remoteMetadataPath);
            }

            Console.WriteLine();
            Console.WriteLine("Finished");
            Console.ReadKey();
        }

        /// <summary>
        /// Outputs the provider contents.
        /// </summary>
        /// <param name="providerLocation">
        /// The provider location.
        /// </param>
        /// <param name="provider">
        /// The provider.
        /// </param>
        private static void OutputProviderContents(String providerLocation, CustomProvider provider)
        {
            Console.WriteLine();
            Console.WriteLine("Contents of provider " + providerLocation);

            foreach (ItemData itemData in provider.GetItemsInMetadata())
            {
                Console.WriteLine(itemData.Id);
            }
        }

        /// <summary>
        /// Outputs the stats.
        /// </summary>
        /// <param name="stats">
        /// The stats.
        /// </param>
        private static void OutputStats(SyncOperationStatistics stats)
        {
            Console.WriteLine("Download applied: " + stats.DownloadChangesApplied);
            Console.WriteLine("Download failed: " + stats.DownloadChangesFailed);
            Console.WriteLine("Download total: " + stats.DownloadChangesTotal);
            Console.WriteLine("Upload applied: " + stats.UploadChangesApplied);
            Console.WriteLine("Upload failed: " + stats.UploadChangesFailed);
            Console.WriteLine("Upload total: " + stats.UploadChangesTotal);
        }

        /// <summary>
        /// Populates the metadata.
        /// </summary>
        /// <param name="localReplicaId">
        /// The local replica id.
        /// </param>
        /// <param name="remoteReplicaId">
        /// The remote replica id.
        /// </param>
        private static void PopulateMetadata(Guid localReplicaId, Guid remoteReplicaId)
        {
            String remoteMetadataPath = BuildMetadataPath(remoteReplicaId);
            String localMetadataPath = BuildMetadataPath(localReplicaId);

            // Use the providers as a way of populating changes into the metadata
            using (CustomProvider localProvider = new CustomProvider(localReplicaId, localMetadataPath, true))
            {
                localProvider.BeginSession(SyncProviderPosition.Unknown, null);
                localProvider.Add(
                    new ItemData
                        {
                            Id = "LocalFirstId"
                        });
                localProvider.Add(
                    new ItemData
                        {
                            Id = "LocalSecondId"
                        });
                localProvider.EndSession(null);
            }

            using (CustomProvider remoteProvider = new CustomProvider(remoteReplicaId, remoteMetadataPath, true))
            {
                remoteProvider.BeginSession(SyncProviderPosition.Unknown, null);
                remoteProvider.Add(
                    new ItemData
                        {
                            Id = "RemoteFirstId"
                        });
                remoteProvider.EndSession(null);
            }
        }

        /// <summary>
        /// Runs the sync.
        /// </summary>
        /// <param name="localReplicaId">
        /// The local replica id.
        /// </param>
        /// <param name="remoteReplicaId">
        /// The remote replica id.
        /// </param>
        /// <param name="isPreview">
        /// If set to <c>true</c> [is preview].
        /// </param>
        /// <param name="filter">
        /// The filter to use.
        /// </param>
        private static void RunSync(Guid localReplicaId, Guid remoteReplicaId, Boolean isPreview, ItemDataFilter filter)
        {
            if (isPreview)
            {
                Console.WriteLine("Running preview sync");
            }
            else
            {
                Console.WriteLine("Running change apply sync");
            }

            if (filter == null)
            {
                Console.WriteLine("Running sync for all items");
            }
            else
            {
                Console.WriteLine("Running sync for with filter for item " + filter.Id);
            }

            Console.WriteLine("__________________________________________________");
            Console.WriteLine();

            String remoteMetadataPath = Path.GetTempPath() + "\\" + remoteReplicaId + ".dat";
            String localMetadataPath = Path.GetTempPath() + "\\" + localReplicaId + ".dat";

            using (
                CustomProvider localProvider = new CustomProvider(localReplicaId, localMetadataPath, isPreview, filter))
            {
                using (
                    CustomProvider remoteProvider = new CustomProvider(
                        remoteReplicaId, remoteMetadataPath, isPreview, filter))
                {
                    SyncOrchestrator runner = new SyncOrchestrator
                                                  {
                                                      LocalProvider = localProvider, 
                                                      RemoteProvider = remoteProvider
                                                  };

                    localProvider.ChangesFound += delegate(Object sender, ChangesFoundEventArgs localArgs)
                                                  {
                                                      Console.WriteLine("Local provide has changes for remote provider");

                                                      foreach (ItemData item in
                                                          localArgs.Changes)
                                                      {
                                                          Console.WriteLine("Id: " + item.Id);
                                                      }
                                                  };

                    remoteProvider.ChangesFound += delegate(Object sender, ChangesFoundEventArgs remoteArgs)
                                                   {
                                                       Console.WriteLine(
                                                           "Remote provide has changes for local provider");

                                                       foreach (ItemData item in
                                                           remoteArgs.Changes)
                                                       {
                                                           Console.WriteLine("Id: " + item.Id);
                                                       }
                                                   };

                    Console.WriteLine("Running sync");
                    SyncOperationStatistics stats = runner.Synchronize();
                    
                    Console.WriteLine();
                    Console.WriteLine("Completed sync");
                    Console.WriteLine();

                    OutputStats(stats);

                    Console.WriteLine();
                    Console.WriteLine("Output provider contents after sync");
                    OutputProviderContents("Local", localProvider);
                    OutputProviderContents("Remote", remoteProvider);
                    Console.WriteLine();
                }
            }
        }
    }
}