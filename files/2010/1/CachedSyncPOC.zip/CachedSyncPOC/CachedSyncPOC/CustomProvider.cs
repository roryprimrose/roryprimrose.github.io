﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using Microsoft.Synchronization;
using Microsoft.Synchronization.MetadataStorage;

namespace CachedSyncPOC
{
    /// <summary>
    /// The <see cref="CustomProvider"/>
    /// class provides the sync provider implementation for operating in sync sessions.
    /// </summary>
    internal class CustomProvider : KnowledgeSyncProvider, ISupportFilteredSync, IRequestFilteredSync, IDisposable
    {
        /// <summary>
        /// The changes found.
        /// </summary>
        public event EventHandler<ChangesFoundEventArgs> ChangesFound;

        /// <summary>
        /// The detect changes.
        /// </summary>
        public event EventHandler DetectChanges;

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomProvider"/> class.
        /// </summary>
        /// <param name="replicaId">
        /// The replica id.
        /// </param>
        /// <param name="metadataStorePath">
        /// The metadata store path.
        /// </param>
        /// <param name="isPreview">
        /// The is Preview.
        /// </param>
        public CustomProvider(Guid replicaId, String metadataStorePath, Boolean isPreview)
        {
            ReplicaId = new SyncId(replicaId);
            StorePath = metadataStorePath;
            IsPreview = isPreview;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomProvider"/> class.
        /// </summary>
        /// <param name="replicaId">
        /// The replica id.
        /// </param>
        /// <param name="metadataStorePath">
        /// The metadata store path.
        /// </param>
        /// <param name="isPreview">
        /// If set to <c>true</c> [is preview].
        /// </param>
        /// <param name="filter">
        /// The filter.
        /// </param>
        public CustomProvider(Guid replicaId, String metadataStorePath, Boolean isPreview, ItemDataFilter filter)
            : this(replicaId, metadataStorePath, isPreview)
        {
            Filter = filter;
        }

        /// <summary>
        /// Adds an item to the metadata.
        /// </summary>
        /// <param name="item">
        /// The item to add.
        /// </param>
        public void Add(ItemData item)
        {
            ItemMetadata metadata = Metadata.FindItemMetadataByIndexedField("Id", item.Id).SingleOrDefault();

            SyncVersion changeVersion = new SyncVersion(0, Metadata.GetNextTickCount());

            SaveMetadata(item, metadata, changeVersion);
        }

        /// <summary>
        /// The add with change.
        /// </summary>
        /// <param name="data">
        /// The data to add.
        /// </param>
        /// <param name="context">
        /// The context.
        /// </param>
        public void AddWithChange(ItemData data, ItemChange context)
        {
            ItemMetadata metadata = Metadata.FindItemMetadataByIndexedField("Id", data.Id).SingleOrDefault();

            if (metadata == null)
            {
                metadata = Metadata.CreateItemMetadata(context.ItemId, context.ChangeVersion);
                metadata.SetCustomField("Id", data.Id);
            }

            SaveMetadata(data, metadata, context.ChangeVersion);
        }

        /// <summary>
        /// The begin session.
        /// </summary>
        /// <param name="position">
        /// The position.
        /// </param>
        /// <param name="syncSessionContext">
        /// The sync session context.
        /// </param>
        /// <exception cref="NotImplementedException">
        /// </exception>
        public override void BeginSession(SyncProviderPosition position, SyncSessionContext syncSessionContext)
        {
            if (Store == null)
            {
                Store = InitStore(StorePath);
            }

            if (Metadata == null)
            {
                Metadata = Store.GetReplicaMetadata(IdFormats, ReplicaId);

                OnDetectChanges(new EventArgs());
            }

            Metadata.SetForgottenKnowledge(new ForgottenKnowledge(Metadata.IdFormats, Metadata.GetKnowledge()));

            Position = position;
            SessionContext = syncSessionContext;
        }

        /// <summary>
        /// The dispose.
        /// </summary>
        public void Dispose()
        {
            Metadata = null;

            IsolationLevel isolation;
            if (Store.IsTransactionActive(out isolation))
            {
                Store.RollbackTransaction();
            }

            ((IDisposable)Store).Dispose();
            Store = null;
        }

        /// <summary>
        /// The end session.
        /// </summary>
        /// <param name="syncSessionContext">
        /// The sync session context.
        /// </param>
        /// <exception cref="NotImplementedException">
        /// </exception>
        public override void EndSession(SyncSessionContext syncSessionContext)
        {
        }

        /// <summary>
        /// The get change batch.
        /// </summary>
        /// <param name="batchSize">
        /// The batch size.
        /// </param>
        /// <param name="destinationKnowledge">
        /// The destination knowledge.
        /// </param>
        /// <param name="changeDataRetriever">
        /// The change data retriever.
        /// </param>
        /// <returns>
        /// A change batch that contains item metadata for items that are not contained in the specified knowledge from the destination provider. Cannot be a null.
        /// </returns>
        /// <exception cref="NotImplementedException">
        /// </exception>
        public override ChangeBatch GetChangeBatch(
            UInt32 batchSize, SyncKnowledge destinationKnowledge, out Object changeDataRetriever)
        {
            ChangeBatch batch;

            if (Filter != null)
            {
                FilterInfo filterInfo = new ItemListFilterInfo(IdFormats);

                batch = Metadata.GetFilteredChangeBatch(batchSize, destinationKnowledge, filterInfo, ItemFilterCallback);
            }
            else
            {
                batch = Metadata.GetChangeBatch(batchSize, destinationKnowledge);
            }

            IList<ItemData> changes = new List<ItemData>(batch.Count());
            ItemDataRetriever retriever = new ItemDataRetriever(Metadata);

            foreach (ItemChange change in batch)
            {
                changes.Add(retriever.LoadFromSyncId(change.ItemId));
            }

            OnChangesFound(
                new ChangesFoundEventArgs
                    {
                        Changes = changes, 
                        ReplicaId = ReplicaId.GetGuidId()
                    });

            changeDataRetriever = retriever;

            return batch;
        }

        /// <summary>
        /// The get full enumeration change batch.
        /// </summary>
        /// <param name="batchSize">
        /// The batch size.
        /// </param>
        /// <param name="lowerEnumerationBound">
        /// The lower enumeration bound.
        /// </param>
        /// <param name="knowledgeForDataRetrieval">
        /// The knowledge for data retrieval.
        /// </param>
        /// <param name="changeDataRetriever">
        /// The change data retriever.
        /// </param>
        /// <returns>
        /// A change batch that contains item metadata for items that have IDs greater than the specified lower bound, as part of a full enumeration.
        /// </returns>
        /// <exception cref="NotImplementedException">
        /// </exception>
        public override FullEnumerationChangeBatch GetFullEnumerationChangeBatch(
            UInt32 batchSize, 
            SyncId lowerEnumerationBound, 
            SyncKnowledge knowledgeForDataRetrieval, 
            out Object changeDataRetriever)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Gets the items in metadata.
        /// </summary>
        /// <returns>
        /// A <see cref="ItemData"/> instance.
        /// </returns>
        public List<ItemData> GetItemsInMetadata()
        {
            List<ItemData> items = new List<ItemData>();

            foreach (ItemMetadata metadata in Metadata.GetAllItems(false))
            {
                items.Add(
                    new ItemData
                        {
                            Id = metadata.GetStringField("Id"), 
                            Data = metadata.GetStringField("Data")
                        });
            }

            return items;
        }

        /// <summary>
        /// The get sync batch parameters.
        /// </summary>
        /// <param name="batchSize">
        /// The batch size.
        /// </param>
        /// <param name="knowledge">
        /// The knowledge.
        /// </param>
        /// <exception cref="NotImplementedException">
        /// </exception>
        public override void GetSyncBatchParameters(out UInt32 batchSize, out SyncKnowledge knowledge)
        {
            batchSize = 10;
            knowledge = Metadata.GetKnowledge();
        }

        /// <summary>
        /// The process change batch.
        /// </summary>
        /// <param name="resolutionPolicy">
        /// The resolution policy.
        /// </param>
        /// <param name="sourceChanges">
        /// The source changes.
        /// </param>
        /// <param name="changeDataRetriever">
        /// The change data retriever.
        /// </param>
        /// <param name="syncCallbacks">
        /// The sync callbacks.
        /// </param>
        /// <param name="sessionStatistics">
        /// The session statistics.
        /// </param>
        /// <exception cref="NotImplementedException">
        /// </exception>
        public override void ProcessChangeBatch(
            ConflictResolutionPolicy resolutionPolicy, 
            ChangeBatch sourceChanges, 
            Object changeDataRetriever, 
            SyncCallbacks syncCallbacks, 
            SyncSessionStatistics sessionStatistics)
        {
            if (IsPreview)
            {
                return;
            }

            // Use a NotifyingChangeApplier object to process the changes. 
            // This object is passed as the INotifyingChangeApplierTarget
            // object that will be called to apply changes to the item store.
            NotifyingChangeApplier changeApplier = new NotifyingChangeApplier(IdFormats);
            INotifyingChangeApplierTarget2 applier = new ItemDataChangeApplier(this, Metadata, Filter);

            changeApplier.ApplyChanges(
                resolutionPolicy, 
                Configuration.CollisionConflictResolutionPolicy, 
                sourceChanges, 
                (IChangeDataRetriever)changeDataRetriever, 
                Metadata.GetKnowledge(), 
                Metadata.GetForgottenKnowledge(), 
                applier, 
                null, 
                SessionContext, 
                syncCallbacks);
        }

        /// <summary>
        /// The process full enumeration change batch.
        /// </summary>
        /// <param name="resolutionPolicy">
        /// The resolution policy.
        /// </param>
        /// <param name="sourceChanges">
        /// The source changes.
        /// </param>
        /// <param name="changeDataRetriever">
        /// The change data retriever.
        /// </param>
        /// <param name="syncCallbacks">
        /// The sync callbacks.
        /// </param>
        /// <param name="sessionStatistics">
        /// The session statistics.
        /// </param>
        /// <exception cref="NotImplementedException">
        /// </exception>
        public override void ProcessFullEnumerationChangeBatch(
            ConflictResolutionPolicy resolutionPolicy, 
            FullEnumerationChangeBatch sourceChanges, 
            Object changeDataRetriever, 
            SyncCallbacks syncCallbacks, 
            SyncSessionStatistics sessionStatistics)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Negotiates which filter is used by the source provider during change enumeration.
        /// </summary>
        /// <param name="filterRequest">
        /// The delegate that is used by the destination provider to request that a filter be used by the source provider during change enumeration.
        /// </param>
        public void SpecifyFilter(FilterRequestCallback filterRequest)
        {
            if (Filter != null)
            {
                if (!filterRequest(Filter, FilteringType.CurrentItemsOnly))
                {
                    throw new Exception("Filter not accepted at source");
                }
            }
        }

        /// <summary>
        /// Sets the filter that is used for change enumeration by the source provider.
        /// </summary>
        /// <param name="filter">
        /// The filter that is used for change enumeration by the source provider.
        /// </param>
        /// <param name="filteringType">
        /// Indicates the type of information that is included in a change batch during filtered synchronization.
        /// </param>
        /// <returns>
        /// True when the filter specified by filter is supported. Otherwise, false.
        /// </returns>
        public Boolean TryAddFilter(Object filter, FilteringType filteringType)
        {
            ISyncFilter syncFilter = filter as ISyncFilter;

            if (syncFilter == null)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Creates the sync id.
        /// </summary>
        /// <returns>
        /// A <see cref="SyncId"/> instance.
        /// </returns>
        private static SyncId CreateSyncId()
        {
            Byte[] syncIdArray = new Byte[24];
            Byte[] guidBytes = Guid.NewGuid().ToByteArray();

            Buffer.BlockCopy(guidBytes, 0, syncIdArray, 4, guidBytes.Length);

            return new SyncId(syncIdArray, false);
        }

        /// <summary>
        /// The init store.
        /// </summary>
        /// <param name="path">
        /// The path used for the store.
        /// </param>
        /// <returns>
        /// A <see cref="SqlMetadataStore"/> instance.
        /// </returns>
        private SqlMetadataStore InitStore(String path)
        {
            if (File.Exists(path))
            {
                return SqlMetadataStore.OpenStore(path, CultureInfo.CurrentCulture);
            }

            SqlMetadataStore store = SqlMetadataStore.CreateStore(path, CultureInfo.CurrentCulture);

            IList<FieldSchema> customFields = new List<FieldSchema>();
            customFields.Add(new FieldSchema("Id", typeof(String), 256));
            customFields.Add(new FieldSchema("Data", typeof(String), 256));

            IList<IndexSchema> indexedFields = new List<IndexSchema>();
            indexedFields.Add(new IndexSchema("Id", true));

            store.InitializeReplicaMetadata(IdFormats, ReplicaId, customFields, indexedFields);

            return store;
        }

        /// <summary>
        /// Items the filter callback.
        /// </summary>
        /// <param name="itemmetadata">
        /// The itemmetadata.
        /// </param>
        /// <returns>
        /// A <see cref="Boolean"/> instance.
        /// </returns>
        private Boolean ItemFilterCallback(ItemMetadata itemmetadata)
        {
            // TODO: Cache this lookup in GetChangeBatch as we don't want to unnecessarily call this lots of times
            ItemMetadata metadata = Metadata.FindItemMetadataByUniqueIndexedField("Id", Filter.Id);

            if (metadata == null)
            {
                return false;
            }

            return itemmetadata.GlobalId == metadata.GlobalId;
        }

        /// <summary>
        /// Raises the <see cref="ChangesFound"/> event.
        /// </summary>
        /// <param name="args">
        /// The <see cref="CachedSyncPOC.ChangesFoundEventArgs"/> instance containing the event data.
        /// </param>
        private void OnChangesFound(ChangesFoundEventArgs args)
        {
            if (ChangesFound != null)
            {
                ChangesFound(this, args);
            }
        }

        /// <summary>
        /// Raises the <see cref="DetectChanges"/> event.
        /// </summary>
        /// <param name="args">
        /// The <see cref="System.EventArgs"/> instance containing the event data.
        /// </param>
        private void OnDetectChanges(EventArgs args)
        {
            if (DetectChanges != null)
            {
                DetectChanges(this, args);
            }
        }

        /// <summary>
        /// Saves the metadata.
        /// </summary>
        /// <param name="item">
        /// The item to save.
        /// </param>
        /// <param name="metadata">
        /// The metadata.
        /// </param>
        /// <param name="changeVersion">
        /// The change version.
        /// </param>
        private void SaveMetadata(ItemData item, ItemMetadata metadata, SyncVersion changeVersion)
        {
            if (metadata == null)
            {
                SyncId syncId = CreateSyncId();

                metadata = Metadata.CreateItemMetadata(syncId, changeVersion);
                metadata.ChangeVersion = metadata.CreationVersion;
                metadata.SetCustomField("Id", item.Id);
            }
            else
            {
                metadata.ChangeVersion = changeVersion;
            }

            metadata.SetCustomField("Data", item.Data);

            Store.BeginTransaction();
            Metadata.SaveItemMetadata(metadata);
            Store.CommitTransaction();
        }

        /// <summary>
        /// Gets IdFormats.
        /// </summary>
        /// <value>
        /// The id formats.
        /// </value>
        public override SyncIdFormatGroup IdFormats
        {
            [DebuggerStepThrough]
            get
            {
                return new SyncIdFormatGroup
                           {
                               ChangeUnitIdFormat =
                                   {
                                       IsVariableLength = false, 
                                       Length = 4
                                   }, 
                               ItemIdFormat =
                                   {
                                       IsVariableLength = false, 
                                       Length = 24
                                   }, 
                               ReplicaIdFormat =
                                   {
                                       // ReplicaIdFormat uses a GUID as an ID
                                       IsVariableLength = false, 
                                       Length = 16
                                   }
                           };
            }
        }

        /// <summary>
        /// Gets or sets Store.
        /// </summary>
        /// <value>
        /// The store.
        /// </value>
        public SqlMetadataStore Store
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets StorePath.
        /// </summary>
        /// <value>
        /// The store path.
        /// </value>
        public String StorePath
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the filter.
        /// </summary>
        /// <value>
        /// The filter.
        /// </value>
        protected ItemDataFilter Filter
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is preview.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is preview; otherwise, <c>false</c>.
        /// </value>
        protected Boolean IsPreview
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets Metadata.
        /// </summary>
        /// <value>
        /// The metadata.
        /// </value>
        protected ReplicaMetadata Metadata
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the position.
        /// </summary>
        /// <value>
        /// The position.
        /// </value>
        protected SyncProviderPosition Position
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets ReplicaId.
        /// </summary>
        /// <value>
        /// The replica id.
        /// </value>
        protected SyncId ReplicaId
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the session context.
        /// </summary>
        /// <value>
        /// The session context.
        /// </value>
        protected SyncSessionContext SessionContext
        {
            get;
            set;
        }
    }
}