using System;
using Microsoft.Synchronization;
using Microsoft.Synchronization.MetadataStorage;

namespace CachedSyncPOC
{
    /// <summary>
    /// THe <see cref="ItemDataChangeApplier"/>
    /// class is used to apply changes provided by the sync framework.
    /// </summary>
    internal class ItemDataChangeApplier : INotifyingChangeApplierTarget2
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ItemDataChangeApplier"/> class.
        /// </summary>
        /// <param name="provider">
        /// The provider.
        /// </param>
        /// <param name="metadata">
        /// The metadata.
        /// </param>
        /// <param name="filterItem">
        /// The filter item.
        /// </param>
        public ItemDataChangeApplier(CustomProvider provider, ReplicaMetadata metadata, ItemDataFilter filterItem)
        {
            Provider = provider;
            Metadata = metadata;
            FilterItem = filterItem;
        }

        /// <summary>
        /// Gets an object that can be used to retrieve item data from a replica.
        /// </summary>
        /// <returns>
        /// An object that can be used to retrieve item data from a replica.
        /// </returns>
        public IChangeDataRetriever GetDataRetriever()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Increments the tick count and returns the new tick count.
        /// </summary>
        /// <returns>
        /// The newly incremented tick count.
        /// </returns>
        public UInt64 GetNextTickCount()
        {
            return Metadata.GetNextTickCount();
        }

        /// <summary>
        /// Saves an item change that contains unit change changes to the item store.
        /// </summary>
        /// <param name="change">
        /// The item change to apply.
        /// </param>
        /// <param name="context">
        /// Information about the change to be applied.
        /// </param>
        public void SaveChangeWithChangeUnits(ItemChange change, SaveChangeWithChangeUnitsContext context)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Saves information about a change that caused a conflict.
        /// </summary>
        /// <param name="conflictingChange">
        /// The item metadata for the conflicting change.
        /// </param>
        /// <param name="conflictingChangeData">
        /// The item data for the conflicting change.
        /// </param>
        /// <param name="conflictingChangeKnowledge">
        /// The knowledge to be learned if this change is applied. This must be saved with the change.
        /// </param>
        public void SaveConflict(
            ItemChange conflictingChange, Object conflictingChangeData, SyncKnowledge conflictingChangeKnowledge)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Saves information about items that are involved in a constraint conflict.
        /// </summary>
        /// <param name="conflictingChange">
        /// The item metadata for the conflicting change from the source provider.
        /// </param>
        /// <param name="conflictingItemId">
        /// The item ID of the item in the destination replica that conflicts with the item specified by conflictingChange.
        /// </param>
        /// <param name="reason">
        /// The reason the conflict occurred.
        /// </param>
        /// <param name="conflictingChangeData">
        /// The item data for the conflicting change.
        /// </param>
        /// <param name="conflictingChangeKnowledge">
        /// The knowledge to be learned if this change is applied. This must be saved with the change.
        /// </param>
        /// <param name="temporary">
        /// True if this is a temporary conflict. Otherwise, false.
        /// </param>
        public void SaveConstraintConflict(
            ItemChange conflictingChange, 
            SyncId conflictingItemId, 
            ConstraintConflictReason reason, 
            Object conflictingChangeData, 
            SyncKnowledge conflictingChangeKnowledge, 
            Boolean temporary)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Saves an item change to the item store.
        /// </summary>
        /// <param name="saveChangeAction">
        /// The action to be performed for the change.
        /// </param>
        /// <param name="change">
        /// The item change to save.
        /// </param>
        /// <param name="context">
        /// Information about the change to be applied.
        /// </param>
        public void SaveItemChange(SaveChangeAction saveChangeAction, ItemChange change, SaveChangeContext context)
        {
            ItemData item = context.ChangeData as ItemData;

            if (item != null && FilterItem != null
                && FilterItem.Id != item.Id)
            {
                context.RecordRecoverableErrorForItem(new RecoverableErrorData(new NotSupportedException()));

                return;
            }

            switch (saveChangeAction)
            {
                case SaveChangeAction.Create:
                case SaveChangeAction.UpdateVersionOnly:
                case SaveChangeAction.UpdateVersionAndData:
                case SaveChangeAction.UpdateVersionAndMergeData:

                    CreateUpdateData(item, change);

                    break;
                case SaveChangeAction.DeleteAndStoreTombstone:
                    break;
                case SaveChangeAction.DeleteAndRemoveTombstone:
                    break;
                case SaveChangeAction.RenameSourceAndUpdateVersionAndData:
                    break;
                case SaveChangeAction.RenameDestinationAndUpdateVersionData:
                    break;
                case SaveChangeAction.DeleteConflictingAndSaveSourceItem:
                    break;
                case SaveChangeAction.StoreMergeTombstone:
                    break;
                case SaveChangeAction.ChangeIdUpdateVersionAndMergeData:
                    break;
                case SaveChangeAction.ChangeIdUpdateVersionAndSaveData:
                    break;
                case SaveChangeAction.ChangeIdUpdateVersionAndDeleteAndStoreTombstone:
                    break;
                case SaveChangeAction.ChangeIdUpdateVersionOnly:
                    break;
                case SaveChangeAction.CreateGhost:
                    break;
                case SaveChangeAction.MarkItemAsGhost:
                    break;
                case SaveChangeAction.UnmarkItemAsGhost:
                    break;
                case SaveChangeAction.UpdateGhost:
                    break;
                case SaveChangeAction.DeleteGhostAndStoreTombstone:
                    break;
                case SaveChangeAction.DeleteGhostWithoutTombstone:
                    break;
                default:
                    throw new ArgumentOutOfRangeException("saveChangeAction");
            }

            // Save the knowledge in the metadata store as each change is applied. 
            // Saving knowledge as each change is applied is not required. 
            // It is more robust than saving the knowledge only after each change batch, 
            // because if synchronization is interrupted before the end of a change batch, 
            // the knowledge will still reflect all of the changes applied. 
            // However, it is less efficient because knowledge must be stored more frequently.
            SyncKnowledge knowledge;
            ForgottenKnowledge forgottenKnowledge;

            context.GetUpdatedDestinationKnowledge(out knowledge, out forgottenKnowledge);

            StoreKnowledgeForScope(knowledge, forgottenKnowledge);
        }

        /// <summary>
        /// Stores the knowledge for the current scope.
        /// </summary>
        /// <param name="knowledge">The knowledge to be saved.</param>
        /// <param name="forgottenKnowledge">The forgotten knowledge to be saved.</param>
        public void StoreKnowledgeForScope(SyncKnowledge knowledge, ForgottenKnowledge forgottenKnowledge)
        {
            Provider.Store.BeginTransaction();
            Metadata.SetKnowledge(knowledge);
            Metadata.SetForgottenKnowledge(forgottenKnowledge);
            Metadata.SaveReplicaMetadata();
            Provider.Store.CommitTransaction();
        }

        /// <summary>
        /// Gets the version of an item stored in the destination replica.
        /// </summary>
        /// <param name="sourceChange">
        /// The item change that is sent by the source provider.
        /// </param>
        /// <param name="destinationVersion">
        /// Returns an item change that contains the version of the item in the destination replica.
        /// </param>
        /// <returns>
        /// <c>true</c> if the item was found in the destination replica; otherwise, <c>false</c>.
        /// </returns>
        public Boolean TryGetDestinationVersion(ItemChange sourceChange, out ItemChange destinationVersion)
        {
            destinationVersion = null;

            ItemMetadata metadata = Metadata.FindItemMetadataById(sourceChange.ItemId);

            if (metadata == null)
            {
                return false;
            }

            ChangeKind changeKind = ChangeKind.Update;

            if (metadata.IsDeleted)
            {
                changeKind = ChangeKind.Deleted;
            }

            ItemChange change = new ItemChange(
                Metadata.IdFormats, 
                Metadata.ReplicaId, 
                sourceChange.ItemId, 
                changeKind, 
                metadata.CreationVersion, 
                metadata.ChangeVersion);

            destinationVersion = change;

            return true;
        }

        /// <summary>
        /// Creates the update data.
        /// </summary>
        /// <param name="item">
        /// The item to update.
        /// </param>
        /// <param name="context">
        /// The context.
        /// </param>
        private void CreateUpdateData(ItemData item, ItemChange context)
        {
            Provider.AddWithChange(item, context);
        }

        /// <summary>
        /// Gets the ID format schema for the provider.
        /// </summary>
        /// <value>
        /// The id formats.
        /// </value>
        /// <returns>
        /// The ID format schema for the provider.
        /// </returns>
        public SyncIdFormatGroup IdFormats
        {
            get
            {
                return Metadata.IdFormats;
            }
        }

        /// <summary>
        /// Gets or sets the filter item.
        /// </summary>
        /// <value>
        /// The filter item.
        /// </value>
        protected ItemDataFilter FilterItem
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the metadata.
        /// </summary>
        /// <value>
        /// The metadata.
        /// </value>
        protected ReplicaMetadata Metadata
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the provider.
        /// </summary>
        /// <value>
        /// The provider.
        /// </value>
        protected CustomProvider Provider
        {
            get;
            set;
        }
    }
}