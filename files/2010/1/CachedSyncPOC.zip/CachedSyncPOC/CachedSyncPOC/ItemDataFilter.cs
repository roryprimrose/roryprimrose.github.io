﻿using System;
using Microsoft.Synchronization;

namespace CachedSyncPOC
{
    /// <summary>
    /// The <see cref="ItemDataFilter"/>
    /// class is used to provide filtering on synchronization sessions.
    /// </summary>
    public class ItemDataFilter : ISyncFilter
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ItemDataFilter"/> class.
        /// </summary>
        /// <param name="id">
        /// The id value.
        /// </param>
        /// <exception cref="ArgumentNullException">
        /// The <paramref name="id"/> value is <c>null</c> or equals <see cref="String.Empty">String.Empty</see>.
        /// </exception>
        public ItemDataFilter(String id)
        {
            // Checks whether the id parameter has been supplied
            if (String.IsNullOrEmpty(id))
            {
                const String IdParameterName = "id";

                throw new ArgumentNullException(IdParameterName);
            }

            Id = id;
        }

        /// <summary>
        /// Indicates whether the specified filter is the same as this filter.
        /// </summary>
        /// <param name="otherFilter">
        /// A filter to compare with this filter.
        /// </param>
        /// <returns>
        /// <c>true</c> when otherFilter is the same as this filter. Otherwise, <c>false</c>.
        /// </returns>
        public Boolean IsIdentical(ISyncFilter otherFilter)
        {
            ItemDataFilter itemFilter = otherFilter as ItemDataFilter;

            return itemFilter != null && Id.Equals(itemFilter.Id);
        }

        /// <summary>
        /// Serializes the filter to an array of bytes.
        /// </summary>
        /// <returns>
        /// The filter data serialized to an array of bytes.
        /// </returns>
        public Byte[] Serialize()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Gets or sets the id.
        /// </summary>
        /// <value>
        /// The id value.
        /// </value>
        public String Id
        {
            get;
            set;
        }
    }
}