﻿namespace NotAWif.ServiceContracts
{
    using System;
    using System.ServiceModel;

    [ServiceContract]
    public interface IService1
    {
        [OperationContract]
        String GetIdentityInformation();
    }
}
