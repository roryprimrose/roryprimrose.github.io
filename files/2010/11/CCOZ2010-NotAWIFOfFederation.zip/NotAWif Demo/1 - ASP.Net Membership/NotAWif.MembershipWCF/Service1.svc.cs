﻿namespace NotAWif.MembershipWCF
{
    using System.Security.Principal;
    using System.Text;
    using System.Threading;
    using NotAWif.ServiceContracts;

    public class Service1 : IService1
    {
        public string GetIdentityInformation()
        {
            StringBuilder builder = new StringBuilder();
            IPrincipal principal = Thread.CurrentPrincipal;
            IIdentity identity = principal.Identity;

            builder.AppendLine("Is authenticated " + identity.IsAuthenticated);
            builder.AppendLine("Authentication type is " + identity.AuthenticationType);
            builder.AppendLine("Your identity type is " + identity.GetType().Name);
            builder.AppendLine("Your identity name is " + identity.Name);
            builder.AppendLine("Is administrator: " + principal.IsInRole("Administrator"));
            builder.AppendLine("Is in random role: " + principal.IsInRole("RandomRole"));

            return builder.ToString();
        }
    }
}
