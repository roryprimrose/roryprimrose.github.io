﻿namespace NotAWif.ClaimsClient
{
    using System;
    using System.ServiceModel;
    using NotAWif.ServiceContracts;

    class Program
    {
        static void Main(string[] args)
        {
            do
            {
                Console.WriteLine();
                Console.Write("Enter user name: ");
                String userName = Console.ReadLine();

                if (String.IsNullOrWhiteSpace(userName)
                    || userName.ToUpperInvariant() == "EXIT")
                {
                    break;
                }

                Console.Write("Enter password: ");
                String password = Console.ReadLine();

                using (ChannelFactory<IService1> factory = new ChannelFactory<IService1>("TestService"))
                {
                    factory.Credentials.SupportInteractive = false;
                    factory.Credentials.UserName.UserName = userName;
                    factory.Credentials.UserName.Password = password;

                    factory.Open();

                    IService1 channel = factory.CreateChannel();

                    try
                    {
                    String data = channel.GetIdentityInformation();

                    Console.WriteLine();
                    Console.WriteLine(data);
                    }
                    catch (Exception ex)
                    {
                        if (ex.InnerException != null)
                        {
                            Console.WriteLine(ex.InnerException.Message);

                        }
                        else
                        {
                            Console.WriteLine(ex.Message);
                        }
                    }

                    factory.Close();
                }
            } while (true);
        }
    }
}
