﻿
namespace NotAWif.ClaimsWeb
{
    using System;
    using System.Security;
    using System.Security.Permissions;
    using Microsoft.IdentityModel.Claims;
    using NotAWif.Security;

    public partial class About : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void DemandRole_Click(object sender, EventArgs e)
        {
            const string Role = "RandomRole";
            PrincipalPermission demandRole = new PrincipalPermission(null, Role);

            try
            {
                demandRole.Demand();

                DemandRoleResponse.Text = "User is in role " + Role;
            }
            catch (SecurityException ex)
            {
                DemandRoleResponse.Text = "Demand role failed: User is not in role - " + ex.Message;
            }
        }

        protected void DemandClaim_Click(object sender, EventArgs e)
        {
            try
            {
                ClaimsPrincipalPermission.CheckAccess(ClaimType.MediaRead, "Photos");

                DemandClaimResponse.Text = "User can read photos";
            }
            catch (Exception ex)
            {
                DemandClaimResponse.Text = "Demand claim failed: User cannot read photos - " + ex.Message;
            }
        }
    }
}
