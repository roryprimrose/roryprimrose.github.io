﻿namespace NotAWif.Security
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Globalization;
    using System.IdentityModel.Tokens;
    using System.Security.Cryptography.X509Certificates;
    using System.Xml;
    using Microsoft.IdentityModel.Tokens;

    public class ConfiguredCertificateIssuerNameRegistry : IssuerNameRegistry
    {
        private struct IssuerCertificateMapping
        {
            public X509FindType FindType;

            public String FindValue;

            public String IssuerName;
        }

        private readonly List<IssuerCertificateMapping> _trustedIssuers = new List<IssuerCertificateMapping>();

        public ConfiguredCertificateIssuerNameRegistry()
        {
        }

        public ConfiguredCertificateIssuerNameRegistry(XmlNodeList customConfiguration)
        {
            if (customConfiguration == null)
            {
                throw new ArgumentNullException("customConfiguration");
            }

            for (Int32 index = 0; index < customConfiguration.Count; index++)
            {
                XmlNode node = customConfiguration[index];

                if (node.Name != "trustedIssuers")
                {
                    continue;
                }

                LoadIssueConfiguration(node);
            }
        }

        public override String GetIssuerName(SecurityToken securityToken)
        {
            if (securityToken == null)
            {
                throw new ArgumentNullException("securityToken");
            }

            X509SecurityToken token = securityToken as X509SecurityToken;

            if (token == null)
            {
                return null;
            }

            X509Certificate2 tokenCertificate = token.Certificate;

            if (tokenCertificate == null)
            {
                return null;
            }

            for (Int32 index = 0; index < TrustedIssuers.Count; index++)
            {
                IssuerCertificateMapping mapping = TrustedIssuers[index];

                if (CertificateMatchesConfigurationItem(tokenCertificate, mapping))
                {
                    
                    return mapping.IssuerName;
                }
            }

            return null;
        }

        private static Boolean CertificateMatchesConfigurationItem(X509Certificate2 tokenCertificate, IssuerCertificateMapping mapping)
        {
            String findValue = mapping.FindValue;

            switch (mapping.FindType)
            {
                case X509FindType.FindByThumbprint:

                    return tokenCertificate.Thumbprint == findValue;

                case X509FindType.FindBySubjectName:

                    return StripToCommonName(tokenCertificate.SubjectName) == findValue;

                case X509FindType.FindBySubjectDistinguishedName:

                    return tokenCertificate.Subject == findValue;

                case X509FindType.FindByIssuerName:

                    return StripToCommonName(tokenCertificate.IssuerName) == findValue;

                case X509FindType.FindByIssuerDistinguishedName:

                    return tokenCertificate.IssuerName.Name == findValue;

                case X509FindType.FindBySerialNumber:

                    return tokenCertificate.SerialNumber == findValue;

                    // case X509FindType.FindByTimeValid:
                    // break;
                    // case X509FindType.FindByTimeNotYetValid:
                    // break;
                    // case X509FindType.FindByTimeExpired:
                    // break;
                    // case X509FindType.FindByTemplateName:
                    // break;
                    // case X509FindType.FindByApplicationPolicy:
                    // break;
                    // case X509FindType.FindByCertificatePolicy:
                    // break;
                    // case X509FindType.FindByExtension:
                    // break;
                    // case X509FindType.FindByKeyUsage:
                    // break;
                    // case X509FindType.FindBySubjectKeyIdentifier:
                    // break;
                default:
                    throw new NotSupportedException();
            }
        }

        private static Nullable<IssuerCertificateMapping> ConvertNodeToCertificateConfiguration(XmlNode node)
        {
            if (node == null)
            {
                throw new ArgumentNullException("node");
            }

            if (node.Attributes == null)
            {
                return null;
            }

            XmlNode findTypeNode = node.Attributes.GetNamedItem("findType");

            if (findTypeNode == null)
            {
                throw new ConfigurationErrorsException("Certificate findType not defined.");
            }

            String configuredFindType = findTypeNode.Value;
            X509FindType findType;

            if (Enum.TryParse(configuredFindType, out findType) == false)
            {
                String message = String.Format(
                    CultureInfo.CurrentCulture, "The findType '{0}' is not a valid X509FindType value.", configuredFindType);

                throw new ConfigurationErrorsException(message);
            }

            XmlNode findValueNode = node.Attributes.GetNamedItem("findValue");

            if (findValueNode == null)
            {
                throw new ConfigurationErrorsException("No findValue has been configured.");
            }

            String findValue = findValueNode.Value;

            if (String.IsNullOrWhiteSpace(findValue))
            {
                throw new ConfigurationErrorsException("No findValue has been defined.");
            }

            XmlNode nameNode = node.Attributes.GetNamedItem("name");

            if (nameNode == null)
            {
                throw new ConfigurationErrorsException("No name has been configured.");
            }

            String name = nameNode.Value;

            if (String.IsNullOrWhiteSpace(name))
            {
                throw new ConfigurationErrorsException("No name has been defined.");
            }

            return new IssuerCertificateMapping
                   {
                       FindType = findType, 
                       FindValue = findValue, 
                       IssuerName = name
                   };
        }

        private static String StripToCommonName(X500DistinguishedName distinguishedName)
        {
            String name = distinguishedName.Name;

            if (String.IsNullOrWhiteSpace(name))
            {
                return null;
            }

            Int32 commonNameIndex = name.LastIndexOf("CN=");

            if (commonNameIndex < 0)
            {
                return null;
            }

            commonNameIndex += 3;

            if (commonNameIndex > name.Length)
            {
                return null;
            }

            return name.Substring(commonNameIndex);
        }

        private void LoadIssueConfiguration(XmlNode node)
        {
            if (node == null)
            {
                throw new ArgumentNullException("node");
            }

            foreach (XmlNode childNode in node.ChildNodes)
            {
                if (childNode.Name == "clear")
                {
                    TrustedIssuers.Clear();
                }
                else
                {
                    Nullable<IssuerCertificateMapping> issuerCertificateConfiguration = ConvertNodeToCertificateConfiguration(childNode);

                    if (issuerCertificateConfiguration == null)
                    {
                        continue;
                    }

                    if (childNode.Name == "add")
                    {
                        TrustedIssuers.Add(issuerCertificateConfiguration.Value);
                    }
                    else if (childNode.Name == "remove")
                    {
                        TrustedIssuers.Remove(issuerCertificateConfiguration.Value);
                    }
                }
            }
        }

        private List<IssuerCertificateMapping> TrustedIssuers
        {
            get
            {
                return _trustedIssuers;
            }
        }
    }
}