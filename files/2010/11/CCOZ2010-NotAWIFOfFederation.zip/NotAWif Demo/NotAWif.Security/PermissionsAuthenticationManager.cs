﻿namespace NotAWif.Security
{
    using System;
    using System.Linq;
    using System.Web.Security;
    using Microsoft.IdentityModel.Claims;

    public class PermissionsAuthenticationManager : ClaimsAuthenticationManager
    {
        public override IClaimsPrincipal Authenticate(String resourceName, IClaimsPrincipal incomingPrincipal)
        {
            IClaimsPrincipal claimsPrincipal = base.Authenticate(resourceName, incomingPrincipal);
          
            IClaimsIdentity claimsIdentity = claimsPrincipal.Identity as IClaimsIdentity;

            if (claimsIdentity == null)
            {
                return claimsPrincipal;
            }

            if (claimsIdentity.IsAuthenticated == false)
            {
                return claimsPrincipal;
            }

            PopulateIdentityWithRoles(claimsIdentity);

            PopulateIdentityPermissions(claimsIdentity);

            return claimsPrincipal;
        }

        private static void PopulateIdentityWithRoles(IClaimsIdentity newIdentity)
        {
            if (Roles.Enabled == false)
            {
                return;
            }

            if (Roles.Provider == null)
            {
                return;
            }

            String[] roles = Roles.Provider.GetRolesForUser(newIdentity.Name);

            foreach (String role in roles)
            {
                String roleToCheck = role;

                if (newIdentity.Claims.Any(x => x.ClaimType == newIdentity.RoleClaimType && x.Value == roleToCheck))
                {
                    // The identity has already been populated with this role
                    continue;
                }

                Claim roleClaim = new Claim(newIdentity.RoleClaimType, role);

                newIdentity.Claims.Add(roleClaim);
            }
        }

        private static void PopulateIdentityPermissions(IClaimsIdentity claimsIdentity)
        {
            MediaPermission[] mediaPermissions = SmallPermissions.GetPermissions(claimsIdentity.Name);

            if (mediaPermissions != null)
            {
                foreach (MediaPermission mediaPermission in mediaPermissions)
                {
                    String claimType = GetClaimType(mediaPermission);

                    if (String.IsNullOrEmpty(claimType))
                    {
                        continue;
                    }

                    Claim newClaim = new Claim(claimType, mediaPermission.Name);

                    if (claimsIdentity.Claims.Any(x => 
                                                  x.ClaimType == newClaim.ClaimType 
                                                  && x.Value == newClaim.Value))
                    {
                        continue;
                    }

                    claimsIdentity.Claims.Add(newClaim);
                }
            }
        }

        private static String GetClaimType(MediaPermission mediaPermission)
        {
            switch (mediaPermission.PermissionType)
            {
                case MediaPermissionType.Create:

                    return ClaimType.MediaCreate;

                case MediaPermissionType.Delete:

                    return ClaimType.MediaDelete;

                case MediaPermissionType.Manage:

                    return ClaimType.MediaManage;

                case MediaPermissionType.Read:

                    return ClaimType.MediaRead;

                case MediaPermissionType.Write:

                    return ClaimType.MediaWrite;

                default:

                    return null;
            }
        }
    }
}
