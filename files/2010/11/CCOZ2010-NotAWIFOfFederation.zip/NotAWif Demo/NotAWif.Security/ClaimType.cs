﻿namespace NotAWif.Security
{
    using System;

    public static class ClaimType
    {
        public const String MediaCreate = "http://schema.notawif.com/claims/permissions/media/create";

        public const String MediaDelete = "http://schema.notawif.com/claims/permissions/media/delete";
        
        public const String MediaManage = "http://schema.notawif.com/claims/permissions/media/manage";
        
        public const String MediaRead = "http://schema.notawif.com/claims/permissions/media/read";
        
        public const String MediaWrite = "http://schema.notawif.com/claims/permissions/media/write";
    }
}
