﻿
namespace NotAWif.Security
{
    using System;

    public class MediaPermission
    {
        public String Name
        {
            get;
            set;
        }

        public MediaPermissionType PermissionType
        {
            get;
            set;
        }
    }
}
