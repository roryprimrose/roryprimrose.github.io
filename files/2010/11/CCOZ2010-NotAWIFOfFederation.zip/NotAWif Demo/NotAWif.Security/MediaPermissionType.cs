﻿namespace NotAWif.Security
{
    public enum MediaPermissionType
    {
        None = 0,

        Create,

        Delete,

        Manage,
        
        Read,

        Write
    }
}
