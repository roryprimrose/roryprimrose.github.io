﻿
namespace NotAWif.Security
{
    using System;
    using System.Collections.Generic;

    public static class SmallPermissions
    {
        private static readonly Dictionary<String, MediaPermission[]> _permissions = PopulatePermissions();

        public static MediaPermission[] GetPermissions(String userName)
        {
            if (String.IsNullOrEmpty(userName))
            {
                return null;
            }

            if (_permissions.ContainsKey(userName) == false)
            {
                return null;
            }

            return _permissions[userName];
        }

        private static Dictionary<String, MediaPermission[]> PopulatePermissions()
        {
            Dictionary<String, MediaPermission[]> permissions = new Dictionary<String, MediaPermission[]>();

            permissions.Add(
                "Rory",
                new[]
                {
                    new MediaPermission
                    {
                        Name = "Photos",
                        PermissionType = MediaPermissionType.Create
                    }, new MediaPermission
                       {
                           Name = "Photos",
                           PermissionType = MediaPermissionType.Read
                       },new MediaPermission
                       {
                           Name = "Photos",
                           PermissionType = MediaPermissionType.Write
                       }
                });

            permissions.Add(
                "User",
                new[]
                {
                    new MediaPermission
                       {
                           Name = "Photos",
                           PermissionType = MediaPermissionType.Read
                       },
                       new MediaPermission
                       {
                           Name = "Music",
                           PermissionType = MediaPermissionType.Manage
                       }
                });

            return permissions;
        }
    }
}
