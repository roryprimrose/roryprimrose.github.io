﻿namespace NotAWif.Security
{
    using System;
    using System.Linq;
    using Microsoft.IdentityModel.Claims;

    public class PermissionsAuthorizationManager : ClaimsAuthorizationManager
    {
        public override bool CheckAccess(AuthorizationContext context)
        {
            for (Int32 index = 0; index < context.Action.Count; index++)
            {
                Claim resourceClaim = context.Resource[index];

                if (resourceClaim.Value != ClaimType.MediaRead)
                {
                    continue;
                }

                Claim actionClaim = context.Action[index];

                if (actionClaim.Value == "Photos")
                {
                    // Check that the authenticated user has this claim
                    foreach (IClaimsIdentity claimsIdentity in context.Principal.Identities)
                    {
                        if (claimsIdentity.Claims.Any(x => x.ClaimType == resourceClaim.Value && x.Value == actionClaim.Value))
                        {
                            return true;
                        }
                    }

                    // The principal does not have the claim that is being requested
                    return false;
                }
            }

            return base.CheckAccess(context);
        }
    }
}