﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NotAWif.STSWeb
{
    using System.Threading;
    using Microsoft.IdentityModel.Claims;

    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            IsAuthenticated.Text = Thread.CurrentPrincipal.Identity.IsAuthenticated.ToString();
            PrincipalType.Text = Thread.CurrentPrincipal.GetType().Name;
            IdentityType.Text = Thread.CurrentPrincipal.Identity.GetType().Name;

            if (Thread.CurrentPrincipal.Identity.IsAuthenticated)
            {
                UserInfo.Visible = true;
                UserName.Text = Thread.CurrentPrincipal.Identity.Name;
                IsAdministrator.Text = Thread.CurrentPrincipal.IsInRole("Administrator").ToString();
                IsRandomRole.Text = Thread.CurrentPrincipal.IsInRole("RandomRole").ToString();

                IClaimsPrincipal claimsPrincipal = Thread.CurrentPrincipal as IClaimsPrincipal;

                if (claimsPrincipal != null)
                {
                    ClaimsIdentities.DataSource = claimsPrincipal.Identities;
                    ClaimsIdentities.DataBind();
                }
            }
            else
            {
                UserInfo.Visible = false;
            }

        }
    }
}
