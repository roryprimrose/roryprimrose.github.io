﻿namespace NotAWif.STSWCF
{
    using System.Security.Principal;
    using System.Text;
    using System.Threading;
    using Microsoft.IdentityModel.Claims;
    using NotAWif.ServiceContracts;

    public class Service1 : IService1
    {
        public string GetIdentityInformation()
        {
            StringBuilder builder = new StringBuilder();
            IPrincipal principal = Thread.CurrentPrincipal;
            IIdentity identity = principal.Identity;

            IClaimsIdentity claimsIdentity = identity as IClaimsIdentity;

            if (claimsIdentity != null 
                && claimsIdentity.Actor != null)
            {
                builder.AppendLine("Identity delegated by " + claimsIdentity.Actor.Name);
            }
            
            builder.AppendLine("Is authenticated " + identity.IsAuthenticated);
            builder.AppendLine("Authentication type is " + identity.AuthenticationType);
            builder.AppendLine("Your identity type is " + identity.GetType().Name);
            builder.AppendLine("Your identity name is " + identity.Name);
            builder.AppendLine("Is administrator: " + principal.IsInRole("Administrator"));
            builder.AppendLine("Is in random role: " + principal.IsInRole("RandomRole"));

            if (claimsIdentity != null)
            {
                foreach (Claim claim in claimsIdentity.Claims)
                {
                    builder.AppendLine();
                    builder.AppendLine("Claim Type: " + claim.ClaimType);
                    builder.AppendLine("Claim Value: " + claim.Value);
                    builder.AppendLine("Claim Issuer: " + claim.Issuer);
                    builder.AppendLine("Claim OriginalIssuer: " + claim.OriginalIssuer);
                }
            }

            return builder.ToString();
        }
    }
}
