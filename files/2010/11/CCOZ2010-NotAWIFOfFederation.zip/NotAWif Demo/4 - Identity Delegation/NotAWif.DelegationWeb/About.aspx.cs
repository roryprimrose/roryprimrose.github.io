﻿
namespace NotAWif.DelegationWeb
{
    using System;
    using System.IdentityModel.Tokens;
    using System.Security;
    using System.Security.Permissions;
    using System.ServiceModel;
    using System.Threading;
    using Microsoft.IdentityModel.Claims;
    using Microsoft.IdentityModel.Web;
    using NotAWif.Security;
    using NotAWif.ServiceContracts;
    using Microsoft.IdentityModel.Protocols.WSTrust;

    public partial class About : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void DemandRole_Click(object sender, EventArgs e)
        {
            const string Role = "RandomRole";
            PrincipalPermission demandRole = new PrincipalPermission(null, Role);

            try
            {
                demandRole.Demand();

                DemandRoleResponse.Text = "User is in role " + Role;
            }
            catch (SecurityException ex)
            {
                DemandRoleResponse.Text = "Demand role failed: User is not in role - " + ex.Message;
            }
        }

        protected void DemandClaim_Click(object sender, EventArgs e)
        {
            try
            {
                ClaimsPrincipalPermission.CheckAccess(ClaimType.MediaRead, "Photos");

                DemandClaimResponse.Text = "User can read photos";
            }
            catch (Exception ex)
            {
                DemandClaimResponse.Text = "Demand claim failed: User cannot read photos - " + ex.Message;
            }
        }

        protected void CallService_Click(object sender, EventArgs e)
        {
            IClaimsPrincipal claimsPrincipal = Thread.CurrentPrincipal as IClaimsPrincipal;

            if (claimsPrincipal == null)
            {
                CallServiceResponse.Text = "Principal is not an IClaimsPrincipal, calling service not supported";

                return;
            }

            SamlSecurityToken securityToken = null;

            foreach (IClaimsIdentity claimsIdentity in claimsPrincipal.Identities)
            {
                SamlSecurityToken token = claimsIdentity.BootstrapToken as SamlSecurityToken;

                if (token != null)
                {
                    securityToken = token;

                    break;
                }
            }

            if (securityToken == null)
            {
                // We lost the session state but the user still has the federated ticket
                // Let's sign the user off and start again               
                FederatedAuthentication.SessionAuthenticationModule.DeleteSessionTokenCookie();
                Response.Redirect(Request.Url.AbsoluteUri);

                return;
            }

            try
            {
                using (ChannelFactory<IService1> factory = new ChannelFactory<IService1>("TestService"))
                {
                    // HACK: Having issues getting localhost cert trusted for the delegated STS call
                    System.Net.ServicePointManager.ServerCertificateValidationCallback =
                        ((sender2, certificate, chain, sslPolicyErrors) => true);

                    factory.ConfigureChannelFactory();

                    factory.Open();

                    IService1 channel = factory.CreateChannelActingAs(securityToken);

                    try
                    {
                        String data = channel.GetIdentityInformation();

                        CallServiceResponse.Text = data.Replace(Environment.NewLine, "<br />");
                    }
                    catch (Exception ex)
                    {
                        CallServiceResponse.Text = ex.ToString().Replace(Environment.NewLine, "<br />");
                    }

                    factory.Close();
                }
            }
            catch (Exception ex)
            {
                // Ignore factory failures
                CallServiceResponse.Text += "<br/>" + ex;
            }
        }
    }
}
