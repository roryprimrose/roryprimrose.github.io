﻿using System;

namespace UnityInjection.BuildTreeDisposal
{
    public class LeafC : ILeaf, IDisposable
    {
        public void Dispose()
        {
            Console.WriteLine("LeafC disposed");
        }
    }
}