﻿using System;

namespace UnityInjection.BuildTreeDisposal
{
    public class ChildA : IChild, IDisposable
    {
        public ChildA(IDependency dependencyA, IDependency dependencyB)
        {
        }

        public void Dispose()
        {
            Console.WriteLine("ChildA disposed");
        }
    }
}