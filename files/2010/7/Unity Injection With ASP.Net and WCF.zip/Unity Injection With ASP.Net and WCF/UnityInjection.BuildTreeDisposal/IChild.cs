﻿namespace UnityInjection.BuildTreeDisposal
{
    public interface IChild
    {
    }
}