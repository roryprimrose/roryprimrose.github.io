﻿namespace UnityInjection.BuildTreeDisposal
{
    public interface ILeaf
    {
    }
}