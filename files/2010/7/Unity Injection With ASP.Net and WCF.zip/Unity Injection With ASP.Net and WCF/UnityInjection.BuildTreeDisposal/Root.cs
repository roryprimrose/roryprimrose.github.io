﻿using System;

namespace UnityInjection.BuildTreeDisposal
{
    public class Root
    {
        public Root(IChild childA, IChild childB)
        {
            
        }
    }
}
