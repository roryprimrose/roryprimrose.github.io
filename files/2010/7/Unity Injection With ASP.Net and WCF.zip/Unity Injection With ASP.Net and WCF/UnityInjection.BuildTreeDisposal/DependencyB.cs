﻿namespace UnityInjection.BuildTreeDisposal
{
    public class DependencyB : IDependency
    {
        public DependencyB(ILeaf leafC)
        {
            
        }
    }
}