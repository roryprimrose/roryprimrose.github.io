﻿namespace UnityInjection.BuildTreeDisposal
{
    public class LeafA : ILeaf
    {
        
    }
}