﻿using System;
using Microsoft.Practices.Unity;
using Neovolve.Toolkit.Unity;

namespace UnityInjection.BuildTreeDisposal
{
    class Program
    {
        static void Main(string[] args)
        {
            IUnityContainer container = UnityContainerResolver.Resolve();

            Root rootInstance = container.Resolve<Root>();

            container.Teardown(rootInstance);

            Console.ReadKey();

            container.Dispose();

            Console.ReadKey();
        }
    }
}
