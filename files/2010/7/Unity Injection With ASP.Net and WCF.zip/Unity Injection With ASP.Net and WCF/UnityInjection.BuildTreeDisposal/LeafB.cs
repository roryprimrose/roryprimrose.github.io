﻿namespace UnityInjection.BuildTreeDisposal
{
    public class LeafB : ILeaf
    {
        
    }
}