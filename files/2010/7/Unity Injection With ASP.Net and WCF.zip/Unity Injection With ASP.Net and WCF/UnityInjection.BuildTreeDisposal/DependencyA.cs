﻿using System;

namespace UnityInjection.BuildTreeDisposal
{
    public class DependencyA : IDependency, IDisposable
    {
        public DependencyA(ILeaf leafA, ILeaf leafB)
        {
            
        }

        public void Dispose()
        {
            Console.WriteLine("DependencyA disposed");
        }
    }
}