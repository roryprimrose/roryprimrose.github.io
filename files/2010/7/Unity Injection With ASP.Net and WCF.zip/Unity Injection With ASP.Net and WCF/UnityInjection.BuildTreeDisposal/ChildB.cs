﻿namespace UnityInjection.BuildTreeDisposal
{
    public class ChildB : IChild
    {
        public ChildB(IDependency dependencyA)
        {
        }
    }
}