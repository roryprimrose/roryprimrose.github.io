﻿namespace UnityInjection.BuildTreeDisposal
{
    public interface IDependency
    {
    }
}