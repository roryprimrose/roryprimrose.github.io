﻿using System;

namespace CoupledCode
{
    public class BusinessHandler
    {
        public String RunAction(Int32 input)
        {
            return "The value provided is " + input;
        }
    }
}
