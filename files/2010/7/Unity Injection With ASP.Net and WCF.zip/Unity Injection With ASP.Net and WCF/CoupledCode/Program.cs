﻿using System;
namespace CoupledCode
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceHandler handler = new ServiceHandler();

            String response = handler.RunAction(234);

            Console.WriteLine(response);
            Console.ReadKey();
        }
    }
}


