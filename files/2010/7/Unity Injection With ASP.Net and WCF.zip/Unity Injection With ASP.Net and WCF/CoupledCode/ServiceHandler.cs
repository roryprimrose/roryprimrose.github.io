﻿using System;

namespace CoupledCode
{
    public class ServiceHandler
    {
        public String RunAction(Int32 input)
        {
            BusinessHandler business = new BusinessHandler();

            return business.RunAction(input);
        }
    }
}


