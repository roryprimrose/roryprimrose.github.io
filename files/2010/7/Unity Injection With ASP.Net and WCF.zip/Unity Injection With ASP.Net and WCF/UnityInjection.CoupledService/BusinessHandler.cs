﻿using System;

namespace UnityInjection.CoupledService
{
    public interface IBusinessOperations
    {
        String RunAction(Int32 input);
    }

    public class BusinessHandler : IBusinessOperations
    {
        public String RunAction(Int32 input)
        {
            return "The value provided is " + input;
        }
    }
}
