﻿using System.ServiceModel;

namespace UnityInjection.CoupledService
{
    [ServiceContract]
    public interface ITestService
    {
        [OperationContract]
        string RunAction(int value);
    }
}
