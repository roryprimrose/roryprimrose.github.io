﻿using System;
using Microsoft.Practices.Unity;
using Neovolve.Toolkit.Unity;

namespace UnityInjection.CoupledService
{
    public class ServiceHandler : ITestService
    {
        private static IUnityContainer _container;
        private readonly IBusinessOperations _business;

        public ServiceHandler()
        {
            if (_container == null)
            {
                _container = UnityContainerResolver.Resolve();
            }

            _business = _container.Resolve<IBusinessOperations>();
        }

        public String RunAction(Int32 value)
        {
            return _business.RunAction(value);
        }
    }
}


