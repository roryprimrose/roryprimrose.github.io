﻿using System;
using Microsoft.Practices.Unity;

namespace UnityBuildUp
{
    public class ServiceHandler
    {
        public String RunAction(Int32 input)
        {
            return Business.RunAction(input);
        }

        [Dependency]
        public IBusinessOperations Business
        {
            get;
            set;
        }
    }
}


