﻿//using System;

//namespace UnityBuildUp
//{
//    public interface IBusinessOperations
//    {
//        String RunAction(Int32 input);
//    }
//}
