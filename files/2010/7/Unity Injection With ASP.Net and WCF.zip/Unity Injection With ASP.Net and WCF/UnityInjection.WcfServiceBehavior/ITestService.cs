﻿using System.ServiceModel;

namespace UnityInjection.WcfServiceBehavior
{
    [ServiceContract]
    public interface ITestService
    {
        [OperationContract]
        string RunAction(int value);
    }
}
