﻿using System.ServiceModel;

namespace UnityInjection.WcfActivation
{
    [ServiceContract]
    public interface ITestService
    {
        [OperationContract]
        string RunAction(int value);
    }
}
