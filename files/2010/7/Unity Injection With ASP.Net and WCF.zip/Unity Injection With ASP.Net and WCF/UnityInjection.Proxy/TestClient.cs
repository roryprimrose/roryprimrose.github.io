﻿using System;
using UnityInjection.TestServiceContracts;

namespace UnityInjection.Proxy
{
    public class TestClient
    {
        private readonly ITestService _dependency;

        public TestClient(ITestService dependency)
        {
            _dependency = dependency;
        }

        public String GetMessage(String data)
        {
            return _dependency.RunAction(data);
        }
    }
}
