﻿
using System;
using Microsoft.Practices.Unity;
using Neovolve.Toolkit.Unity;

namespace UnityInjection.Proxy
{
    class Program
    {
        static void Main(string[] args)
        {
            IUnityContainer container = UnityContainerResolver.Resolve();

            Console.WriteLine("Press a key to invoke service dependency");
            Console.ReadKey();

            TestClient testClient = container.Resolve<TestClient>();

            String message = testClient.GetMessage("Data from client");

            Console.WriteLine(message);
            Console.ReadKey();
        }
    }
}
