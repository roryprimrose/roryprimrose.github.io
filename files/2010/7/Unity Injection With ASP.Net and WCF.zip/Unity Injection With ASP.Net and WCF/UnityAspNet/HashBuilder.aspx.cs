﻿using System;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Practices.Unity;

namespace UnityAspNet
{
    public partial class HashBuilder : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            String originalValue = Guid.NewGuid().ToString();
            Byte[] data = Encoding.UTF8.GetBytes(originalValue);
            Byte[] hashedData = Calculator.ComputeHash(data);
            String hashedValue = Convert.ToBase64String(hashedData);

            OriginalValue.Text = originalValue;
            HashValue.Text = hashedValue;
        }

        [Dependency]
        public HashAlgorithm Calculator
        {
            get;
            set;
        }
    }
}


