﻿using System;
using System.ServiceModel;

namespace UnityInjection.TestServiceContracts
{
    [ServiceContract]
    public interface ITestService
    {
        [OperationContract]
        String RunAction(String data);
    }
}
