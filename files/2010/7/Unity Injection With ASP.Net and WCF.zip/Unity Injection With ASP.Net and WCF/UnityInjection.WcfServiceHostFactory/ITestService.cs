﻿using System.ServiceModel;

namespace UnityInjection.WcfServiceHostFactory
{
    [ServiceContract]
    public interface ITestService
    {
        [OperationContract]
        string RunAction(int value);
    }
}
