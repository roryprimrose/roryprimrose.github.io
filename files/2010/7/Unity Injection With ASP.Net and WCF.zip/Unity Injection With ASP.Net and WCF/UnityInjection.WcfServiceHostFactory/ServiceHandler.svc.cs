﻿using System;

namespace UnityInjection.WcfServiceHostFactory
{
    public class ServiceHandler : ITestService
    {
        private readonly IBusinessOperations _business;

        public ServiceHandler(IBusinessOperations business)
        {
            _business = business;
        }

        public String RunAction(Int32 value)
        {
            return _business.RunAction(value);
        }
    }
}


