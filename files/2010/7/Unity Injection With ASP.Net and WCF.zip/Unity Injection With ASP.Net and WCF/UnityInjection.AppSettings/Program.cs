﻿using System;
using Microsoft.Practices.Unity;
using Neovolve.Toolkit.Unity;

namespace UnityInjection.AppSettings
{
    class Program
    {
        static void Main(string[] args)
        {
            IUnityContainer container = UnityContainerResolver.Resolve();

            container.Resolve<RenderAppSettings>();
            container.Resolve<RenderConnectionSettings>();

            Console.ReadKey();
        }
    }
}
