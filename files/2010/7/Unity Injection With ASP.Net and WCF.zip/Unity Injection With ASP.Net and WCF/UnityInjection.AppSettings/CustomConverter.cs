﻿using System;
using System.ComponentModel;

namespace UnityInjection.AppSettings
{
    public class CustomConverter : TypeConverter
    {
        public override object ConvertFrom(ITypeDescriptorContext context, System.Globalization.CultureInfo culture, object value)
        {
            if (value.GetType().Equals(typeof(String)))
            {
                String original = value as String;

                return original.Split(',');
            }

            return base.ConvertFrom(context, culture, value);
        }
    }
}
