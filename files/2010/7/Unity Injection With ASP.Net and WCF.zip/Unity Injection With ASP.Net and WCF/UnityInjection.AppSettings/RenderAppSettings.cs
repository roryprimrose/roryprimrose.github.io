﻿    using System;

namespace UnityInjection.AppSettings
{
    public class RenderAppSettings
    {
        public RenderAppSettings(String stringValue, Int32 integerValue, String[] customTypeValues)
        {
            Console.WriteLine("String value: " + stringValue);
            Console.WriteLine("Integer value: " + integerValue);

            for (int index = 0; index < customTypeValues.Length; index++)
            {
                Console.WriteLine(index + ": " + customTypeValues[index]);
            }
        }
    }
}
