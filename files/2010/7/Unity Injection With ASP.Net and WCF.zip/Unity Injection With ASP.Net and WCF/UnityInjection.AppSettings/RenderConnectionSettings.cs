﻿using System;
using System.Configuration;

namespace UnityInjection.AppSettings
{
    class RenderConnectionSettings
    {
        public RenderConnectionSettings(String connectionString, ConnectionStringSettings settings)
        {
            Console.WriteLine("Connection string: " + connectionString);
            Console.WriteLine("Connection setting string: " + settings.ConnectionString);
            Console.WriteLine("Connection setting name: " + settings.Name);
            Console.WriteLine("Connection setting provider: " + settings.ProviderName);
        }
    }
}
