﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using UnityInjection.TestServiceContracts;

namespace UnityInjection.TestService
{
    class Program
    {
        static void Main(string[] args)
        {
            Uri endpointAddress = new Uri("net.pipe://localhost/TestService");
            using (ServiceHost host = new ServiceHost(typeof(TestService), new[]{endpointAddress, }))
            {
                host.AddServiceEndpoint(typeof(ITestService), new NetNamedPipeBinding(), endpointAddress);

                host.Open();

                Console.WriteLine("Service is running, press a key to close service.");
                Console.ReadKey();
                
                host.Close();
            }
        }
    }

    public class TestService : ITestService
    {
        public string RunAction(string data)
        {
            Console.WriteLine("'" + data + "' was received from the client");

            return "The data provided was: " + data;
        }
    }
}
