﻿using System;

namespace UnityInjection
{
    public class ServiceHandler
    {
        private readonly IBusinessOperations _business;

        public ServiceHandler(IBusinessOperations business)
        {
            _business = business;
        }

        public String RunAction(Int32 input)
        {
            return _business.RunAction(input);
        }
    }
}


