﻿using System;
using Microsoft.Practices.Unity;

namespace UnityInjection
{
    class Program
    {
        static void Main(string[] args)
        {
            UnityContainer container = new UnityContainer();

            container.RegisterType(typeof(IBusinessOperations), 
                typeof(BusinessHandler));

            ServiceHandler handler = container.Resolve<ServiceHandler>();

            String response = handler.RunAction(234);

            Console.WriteLine(response);
            Console.ReadKey();
        }
    }
}


