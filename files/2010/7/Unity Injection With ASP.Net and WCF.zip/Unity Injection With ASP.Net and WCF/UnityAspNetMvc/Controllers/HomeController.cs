﻿using System;
using System.Security.Cryptography;
using System.Text;
using System.Web.Mvc;

namespace UnityAspNetMvc.Controllers
{
    [HandleError]
    public class HomeController : Controller
    {
        private readonly HashAlgorithm _hashCalculator;

        public HomeController(HashAlgorithm hashCalculator)
        {
            _hashCalculator = hashCalculator;    
        }

        public ActionResult Index()
        {
            String originalValue = Guid.NewGuid().ToString();
            Byte[] data = Encoding.UTF8.GetBytes(originalValue);
            Byte[] hashedData = _hashCalculator.ComputeHash(data);
            String hashedValue = Convert.ToBase64String(hashedData);

            ViewData["Message"] = "The hash value for " + originalValue + " is " + hashedValue;

            return View();
        }

        public ActionResult About()
        {
            return View();
        }
    }
}
