﻿using System;
using System.ServiceModel;

namespace Neovolve.Framework.Communication.SecurityHost
{
    [ServiceContract]
    public interface IService1
    {
        [OperationContract]
        String GetContextPassword();

        [OperationContract]
        String GetContextUserName();

        [OperationContract]
        Boolean GetIsCorrectContextIdentity();

        [OperationContract]
        Boolean GetIsCorrectThreadIdentity();

        [OperationContract]
        String GetThreadPassword();

        [OperationContract]
        String GetThreadUserName();
    }
}