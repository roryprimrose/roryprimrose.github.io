﻿using System;
using System.ServiceModel;
using System.Threading;
using Neovolve.Framework.Communication.Security;

namespace Neovolve.Framework.Communication.SecurityHost
{
    public class Service1 : IService1
    {
        public String GetContextPassword()
        {
            if (GetIsCorrectContextIdentity())
            {
                return ((PasswordIdentity)ServiceSecurityContext.Current.PrimaryIdentity).Password;
            }

            return String.Empty;
        }

        public String GetContextUserName()
        {
            return ServiceSecurityContext.Current.PrimaryIdentity.Name;
        }

        public Boolean GetIsCorrectContextIdentity()
        {
            return ServiceSecurityContext.Current.PrimaryIdentity is PasswordIdentity;
        }

        public Boolean GetIsCorrectThreadIdentity()
        {
            return Thread.CurrentPrincipal.Identity is PasswordIdentity;
        }

        public String GetThreadPassword()
        {
            if (GetIsCorrectThreadIdentity())
            {
                return ((PasswordIdentity)Thread.CurrentPrincipal.Identity).Password;
            }

            return String.Empty;
        }

        public String GetThreadUserName()
        {
            return Thread.CurrentPrincipal.Identity.Name;
        }
    }
}