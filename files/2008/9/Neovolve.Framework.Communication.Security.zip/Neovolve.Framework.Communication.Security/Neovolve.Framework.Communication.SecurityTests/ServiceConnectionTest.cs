﻿using System;
using System.Diagnostics;
using System.ServiceModel;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Neovolve.Framework.Communication.SecurityHost;

namespace Neovolve.Framework.Communication.SecurityTests
{
    /// <summary>
    /// Summary description for ServiceConnectionTest
    /// </summary>
    [TestClass]
    public class ServiceConnectionTest
    {
        [TestMethod]
        public void CallServiceTest()
        {
            ChannelFactory<IService1> channelFactory = null;
            try
            {
                channelFactory = new ChannelFactory<IService1>("PasswordSecurityTest");

                String userName = Guid.NewGuid().ToString();
                String password = Guid.NewGuid().ToString();

                channelFactory.Credentials.UserName.UserName = userName;
                channelFactory.Credentials.UserName.Password = password;

                channelFactory.Open();

                IService1 channel = channelFactory.CreateChannel();

                Assert.IsTrue(channel.GetIsCorrectThreadIdentity(), "GetIsCorrectThreadIdentity returned an incorrect value.");

                String expectedThreadUserName = channel.GetThreadUserName();
                Assert.AreEqual(expectedThreadUserName, userName, "GetThreadUserName returned an incorrect value.");

                String expectedThreadPassword = channel.GetThreadPassword();
                Assert.AreEqual(expectedThreadPassword, password, "GetThreadPassword returned an incorrect value.");

                Assert.IsTrue(channel.GetIsCorrectContextIdentity(), "GetIsCorrectContextIdentity returned an incorrect value.");

                String expectedContextUserName = channel.GetContextUserName();
                Assert.AreEqual(expectedContextUserName, userName, "GetContextUserName returned an incorrect value.");

                String expectedContextPassword = channel.GetContextPassword();
                Assert.AreEqual(expectedContextPassword, password, "GetContextPassword returned an incorrect value.");

                channelFactory.Close();
            }
            catch (CommunicationException ex)
            {
                Debug.WriteLine(ex);

                if (channelFactory != null)
                {
                    channelFactory.Abort();
                }

                throw;
            }
            catch (TimeoutException ex)
            {
                Debug.WriteLine(ex);

                if (channelFactory != null)
                {
                    channelFactory.Abort();
                }

                throw;
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);

                if (channelFactory != null)
                {
                    channelFactory.Abort();
                }

                throw;
            }
        }

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get;
            set;
        }
    }
}