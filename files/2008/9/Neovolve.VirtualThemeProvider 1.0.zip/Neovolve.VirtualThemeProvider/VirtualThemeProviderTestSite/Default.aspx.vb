
Partial Class _Default

    Inherits System.Web.UI.Page

    Protected Sub Page_PreInit(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreInit

        Theme = Request.QueryString("Theme")

        ddlSets.SelectedValue = Neovolve.VirtualThemeProvider.VirtualThemePathProvider.Current.CurrentSet

    End Sub

    Protected Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.PreRender

        ddlThemes.SelectedValue = Theme

    End Sub

    Protected Sub ddlSets_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlSets.SelectedIndexChanged

        Neovolve.VirtualThemeProvider.VirtualThemePathProvider.Current.CurrentSet = ddlSets.SelectedValue

    End Sub

End Class
