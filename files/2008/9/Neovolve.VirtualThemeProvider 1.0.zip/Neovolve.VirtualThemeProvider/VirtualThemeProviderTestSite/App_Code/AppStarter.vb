Imports Microsoft.VisualBasic
Imports System.Web.Hosting

Public Class AppStarter

    Public Shared Sub AppInitialize()

        HostingEnvironment.RegisterVirtualPathProvider(Neovolve.VirtualThemeProvider.VirtualThemePathProvider.Current)

    End Sub

End Class
