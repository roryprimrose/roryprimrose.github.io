using System;
using System.Collections.Generic;
using System.Text;
using System.Web;

namespace Neovolve.VirtualThemeProvider
{
    /// <summary>
    /// The <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemePathProvider"/> provides a flexible virtual file system for themes.
    /// This provider provides support for combining theme files from the theme directory and a global directory and provides filtering support based on filter set definitions.
    /// </summary>
    /// <remarks>
    /// 
    /// <para>In order for the <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemePathProvider"/> to be called, the <c>App_Themes</c> directory needs to exist, 
    /// but cannot contain the theme directories for which this provider will provide the virtual files system. 
    /// When the <c>App_Themes</c> directory doesn't exist, ASP.Net will eventually throw an <see cref="T:System.Web.HttpException"/> 
    /// because it can't monitor the changes for that directory. When a theme directory is requested, the theme directory will not be found in <c>App_Themes</c> and the
    /// <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemePathProvider"/> will be called upon to provide the file system information.</para>
    /// 
    /// <para>Without any configuration, this provider will support merging the current theme with the global directory. By default, the relative path of the applications theme 
    /// directory (the custom version of <c>App_Themes</c>) will be a directory called <c>Themes</c> in the web applications root directory 
    /// (as defined by the relative path <c>Themes/</c>). In the application theme directory, the default global directory will be called <c>Global</c>.
    /// A different relative path to the application theme directory can be set by storing an application setting in the <c>web.config</c> file using the key value
    /// <see cref="F:Neovolve.VirtualThemeProvider.VirtualThemePathProvider.ThemeRelativePathKey">VirtualThemePathProviderThemePath</see>.
    /// A different global directory name can be set by storing an application setting in the <c>web.config</c> using the key value
    /// <see cref="F:Neovolve.VirtualThemeProvider.VirtualThemePathProvider.GlobalThemeNameKey">VirtualThemePathProviderGlobalThemeName</see>.</para>
    /// 
    /// <para>When the <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemePathProvider"/> determines the files that are available in a 
    /// <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemeDirectory"/>, it will first determine whether the file physically exists in the theme directory. 
    /// If the file physically exists in the theme directory, the file name will be checked against the <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDefinition" /> 
    /// if one is found in the theme directory. If no <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDefinition" /> file exists, 
    /// or no <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterSet" /> can be applied, the file will be included. 
    /// Where a <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterSet" /> can be applied, the file will 
    /// be included in the theme according to the rules defined in that <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterSet" />. 
    /// If the outcome is that the file is not included for any of these reasons, the same rules are applied to the
    /// same file name in the same directory hierarchy (relative to the base theme directory) if it exists. Due to the order in which the file inclusion rules are applied, 
    /// a file in the theme directory takes precedence over the file in the related global directory where both files are to be included in the theme.</para>
    /// 
    /// <para>To use the filtering support in this provider, refer to the Remarks section for the 
    /// <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDefinition"/> class.</para>
    /// 
    /// <para><b>Note:</b> Before using any <see cref="T:System.Web.Hosting.VirtualPathProvider"/>, the provider needs to be registered with the web application. 
    /// See <see cref="M:System.Web.Hosting.HostingEnvironment.RegisterVirtualPathProvider">HostingEnvironment.RegisterVirtualPathProvider</see> for further information.</para>
    /// 
    /// </remarks>
    /// <seealso cref="M:System.Web.Hosting.HostingEnvironment.RegisterVirtualPathProvider">System.Web.Hosting.HostingEnvironment.RegisterVirtualPathProvider</seealso>
    /// <seealso cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDefinition">Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDefinition</seealso>
    /// <seealso cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterSet">Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterSet</seealso>
    public sealed class VirtualThemePathProvider : System.Web.Hosting.VirtualPathProvider
    {
        #region Declarations

        /// <summary>
        /// Stores the singleton object reference.
        /// </summary>
        /// <remarks>None.</remarks>
        private static VirtualThemePathProvider _currentProvider = null;

        /// <summary>
        /// Defines the prefix to add to the keys used to store items in cache.
        /// </summary>
        /// <remarks>
        /// This prefix is combined with the key values in order to avoid the unlikely scenario where another assembly happens to place an object
        /// in cache with the same key value that is used by this assembly.
        /// </remarks>
        internal const String CacheKeyPrefix = "VirtualThemePathProvider";

        /// <summary>
        /// Defines the name of the ASP.Net theme directory.
        /// </summary>
        /// <remarks>None.</remarks>
        private const String ASPNetThemeBasePath = "/App_Themes/";

        /// <summary>
        /// Defines the name of the file that contains the <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDefinition"/> data.
        /// </summary>
        /// <remarks>None.</remarks>
        public const String FilterDefinitionFileName = "VirtualThemePathFilters.config";

        // ______________________________________________________________________
        //
        // Theme path constants and declarations
        // ______________________________________________________________________

        /// <summary>
        /// Defines the application settings key to load the theme relative path from <c>web.config</c>.
        /// </summary>
        /// <remarks>None.</remarks>
        public const String ThemeRelativePathKey = "VirtualThemePathProviderThemePath";

        /// <summary>
        /// Defines the default relative themes path to use if no value is found in <c>web.config</c>.
        /// </summary>
        /// <remarks>None.</remarks>
        public const String DefaultThemeRelativePath = "Themes/";

        /// <summary>
        /// Stores the relative path to the directory that contains the themes.
        /// </summary>
        /// <remarks>None.</remarks>
        private String _themeRelativePath = String.Empty;

        // ______________________________________________________________________
        //
        // Global theme name constants and declarations
        // ______________________________________________________________________

        /// <summary>
        /// Defines the application settings key to load the global theme name from <c>web.config</c>.
        /// </summary>
        /// <remarks>None.</remarks>
        public const String GlobalThemeNameKey = "VirtualThemePathProviderGlobalThemeName";

        /// <summary>
        /// Defines the default global theme name to use if no value is found in <c>web.config</c>.
        /// </summary>
        /// <remarks>None.</remarks>
        public const String DefaultGlobalThemeName = "Global";

        /// <summary>
        /// Stores the global theme name.
        /// </summary>
        /// <remarks>None.</remarks>
        private String _globalThemeName = String.Empty;

        // ______________________________________________________________________
        //
        // Default filter set constants and declarations
        // ______________________________________________________________________

        /// <summary>
        /// Defines the application settings key to load the default filter set name from <c>web.config</c>.
        /// </summary>
        /// <remarks>None.</remarks>
        public const String DefaultSetKey = "VirtualThemePathProviderDefaultSet";

        /// <summary>
        /// Defines the default filter set name to use if no value is found in <c>web.config</c>.
        /// </summary>
        /// <remarks>None.</remarks>
        private const String DefaultSetValue = "";

        /// <summary>
        /// Stores the default filter set.
        /// </summary>
        /// <remarks>None.</remarks>
        private String _defaultSet = null;

        // ______________________________________________________________________
        //
        // State scope constants and declarations
        // ______________________________________________________________________

        /// <summary>
        /// Defines the application settings key to load the state scope from <c>web.config</c>.
        /// </summary>
        /// <remarks>None.</remarks>
        public const String StateScopeKey = "VirtualThemePathProviderStateScope";

        /// <summary>
        /// Defines the user state scope name.
        /// </summary>
        /// <remarks>None.</remarks>
        public const String UserStateScopeName = "User";

        /// <summary>
        /// Defines the applications state scope name.
        /// </summary>
        /// <remarks>None.</remarks>
        public const String ApplicationStateScopeName = "Application";

        /// <summary>
        /// Defines the default value to determine the scope if no value is found in <c>web.config</c>.
        /// </summary>
        /// <remarks>None.</remarks>
        public const String DefaultStateScope = UserStateScopeName;

        /// <summary>
        /// Stores the state scope.
        /// </summary>
        /// <remarks>None.</remarks>
        private String _stateScope = null;

        /// <summary>
        /// Defines the cookie key to use for storing cookie scope filter sets.
        /// </summary>
        /// <remarks>None.</remarks>
        private const String CookieStateScopeKey = "VirtualThemePathProviderCookieStateScope";

        /// <summary>
        /// Stores the name of the current set for the application state scope.
        /// </summary>
        /// <remarks>None.</remarks>
        private String _currentApplicationSet = null;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemePathProvider"/> class.
        /// </summary>
        /// <remarks>None.</remarks>
        private VirtualThemePathProvider()
        {
        }
        
        #endregion

        #region Functions

        /// <summary>
        /// Gets a value that indicates whether a directory exists in the virtual file system.
        /// </summary>
        /// <param name="virtualDir">The path to the virtual directory.</param>
        /// <returns><see langword="true"/> if the directory exists in the virtual file system; otherwise, <see langword="false"/>.</returns>
        /// <remarks>None.</remarks>
        public override bool DirectoryExists(string virtualDir)
        {
            // If the virtual directory path doesn't contain App_Themes, then this provider isn't responsible for answering the question
            if (virtualDir.IndexOf(ASPNetThemeBasePath) == -1)
                return base.DirectoryExists(virtualDir);

            // Get the directory reference
            VirtualThemeDirectory directory = GetDirectory(virtualDir) as VirtualThemeDirectory;

            // Return whether the directory physically exists
            return directory.Exists;
        }

        /// <summary>
        /// Gets a value that indicates whether a file exists in the virtual file system.
        /// </summary>
        /// <param name="virtualPath">The path to the virtual file.</param>
        /// <returns><see langword="true"/> if the file exists in the virtual file system; otherwise, <see langword="false"/>.</returns>
        /// <remarks>None.</remarks>
        public override bool FileExists(string virtualPath)
        {
            // If the virtual directory path doesn't contain App_Themes, then this provider isn't responsible for answering the question
            if (virtualPath.IndexOf(ASPNetThemeBasePath) == -1)
                return base.FileExists(virtualPath);

            // Get the name of the file in the virtual request
            String fileName = System.Web.VirtualPathUtility.GetFileName(virtualPath);

            // Ensure that the filter config files are never included in the providers file set
            if (fileName.Equals(VirtualThemePathProvider.FilterDefinitionFileName) == true)
                return false;

            // Get the directory path of the virtual file path
            String virtualDirectoryPath = System.Web.VirtualPathUtility.GetDirectory(virtualPath);

            // Get the directory for the path
            VirtualThemeDirectory directory = GetDirectory(virtualDirectoryPath) as VirtualThemeDirectory;

            // Return whether the directory exposes the file for the current set
            return directory.GetFileIsIncluded(fileName);
        }

        /// <summary>
        /// Gets a virtual directory from the virtual file system.
        /// </summary>
        /// <param name="virtualDir">The path to the virtual directory.</param>
        /// <returns>
        /// A descendent of the <see cref="T:System.Web.Hosting.VirtualDirectory"></see> class that represents a directory in the virtual file system.
        /// </returns>
        /// <remarks>None.</remarks>
        public override System.Web.Hosting.VirtualDirectory GetDirectory(string virtualDir)
        {
            // If the virtual directory path doesn't contain App_Themes, then this provider isn't responsible for answering the question
            if (virtualDir.IndexOf(ASPNetThemeBasePath) == -1)
                return base.GetDirectory(virtualDir);

            // Check if this virtual path is for the theme directory or a subdirectory
            if (IsThemeDirectoryVirtualPath(virtualDir) == true)
            {
                // Return the theme directory from cache. This will be created if it doesn't yet exist.
                return GetDirectoryFromCache(virtualDir);
            }
            else
            {
                // This is a descendent virtual directory of the theme directory
                String themeVirtualPath = GetThemeDirectoryVirtualPath(virtualDir);

                // Get the theme directory
                VirtualThemeDirectory directory = GetDirectoryFromCache(themeVirtualPath);

                // Return the descendent directory
                return directory.GetDirectory(virtualDir);
            }
        }

        /// <summary>
        /// Gets a virtual file from the virtual file system.
        /// </summary>
        /// <param name="virtualPath">The path to the virtual file.</param>
        /// <returns>
        /// A descendent of the <see cref="T:System.Web.Hosting.VirtualDirectory"></see> class that represents a file in the virtual file system.
        /// </returns>
        /// <remarks>None.</remarks>
        public override System.Web.Hosting.VirtualFile GetFile(string virtualPath)
        {
            // If the virtual directory path doesn't contain App_Themes, then this provider isn't responsible for answering the question
            if (virtualPath.IndexOf(ASPNetThemeBasePath) == -1)
                return base.GetFile(virtualPath);

            // Get the directory path of the virtual file path
            String virtualDirectoryPath = System.Web.VirtualPathUtility.GetDirectory(virtualPath);

            // Get the directory for the path
            VirtualThemeDirectory directory = GetDirectory(virtualDirectoryPath) as VirtualThemeDirectory;

            // Get the name of the file
            String fileName = System.Web.VirtualPathUtility.GetFileName(virtualPath);

            // Return the file from the directory
            return directory.GetFile(fileName);
        }

        /// <summary>
        /// Creates a cache dependency based on the specified virtual paths.
        /// </summary>
        /// <param name="virtualPath">The path to the primary virtual resource.</param>
        /// <param name="virtualPathDependencies">An array of paths to other resources required by the primary virtual resource.</param>
        /// <param name="utcStart">The UTC time at which the virtual resources were read.</param>
        /// <returns>
        /// A <see cref="T:System.Web.Caching.CacheDependency" /> object for the specified virtual resources.
        /// </returns>
        /// <remarks>
        /// The <see cref="T:System.Web.Caching.CacheDependency" /> returned contains a list of all the directories that exist under
        /// the theme directory. Cache keys and the cache date are not used to create this cache dependency. 
        /// The <paramref name="virtualPathDependecies"/> and <paramref name="utcStart"/> parameters are ignored and are not used to create the cache dependency.
        /// </remarks>
        public override System.Web.Caching.CacheDependency GetCacheDependency(string virtualPath, System.Collections.IEnumerable virtualPathDependencies, DateTime utcStart)
        {            
            // If the virtual directory path doesn't contain App_Themes, then this provider isn't responsible for answering the question
            if (virtualPath.IndexOf(ASPNetThemeBasePath) == -1)
                return base.GetCacheDependency(virtualPath, virtualPathDependencies, utcStart);

            System.Collections.Specialized.StringCollection directoryDependencies = new System.Collections.Specialized.StringCollection();

            // Get the relative path for the theme directory
            String themeRelativePath = VirtualThemePathProvider.Current.ConvertToThemeRelativePath(virtualPath);

            // Convert the relative path into an absolute path
            String themeAbsolutePath = HttpContext.Current.Server.MapPath(themeRelativePath);

            // Check if the theme directory exists
            if (System.IO.Directory.Exists(themeAbsolutePath) == true)
            {
                // Add the theme path as a dependency
                directoryDependencies.Add(themeAbsolutePath);

                // Determine the paths of all the directories below the theme directory
                GetDependentDirectories(themeAbsolutePath, directoryDependencies);
            }

            // Get the relative path for the global theme directory
            String globalRelativePath = VirtualThemePathProvider.Current.ConvertToGlobalRelativePath(virtualPath);

            // Convert the relative path into an absolute path
            String globalAbsolutePath = HttpContext.Current.Server.MapPath(globalRelativePath);

            // Check if the global directory exists
            if (System.IO.Directory.Exists(globalAbsolutePath) == true)
            {
                // Add the global path as a dependency
                directoryDependencies.Add(globalAbsolutePath);

                // Determine the paths of all the directories below the global directory
                GetDependentDirectories(globalAbsolutePath, directoryDependencies);
            }

            // If there are no directory dependencies found, return null
            if (directoryDependencies.Count == 0)
                return null;

            // Copy the list of full-path dependencies into an array.
            String[] fullPathDependenciesArray = new String[directoryDependencies.Count];
            directoryDependencies.CopyTo(fullPathDependenciesArray, 0);

            // Return the cache dependency
            return new System.Web.Caching.CacheDependency(fullPathDependenciesArray);
        }

        /// <summary>
        /// Returns a collection of paths of the decendent directories.
        /// </summary>
        /// <param name="parentDirectoryPath">The parent directory path.</param>
        /// <param name="dependentPaths">The dependent paths already determined. New directory paths encountered are added to this object.</param>
        /// <returns>A <see cref="T:System.Collections.Specialized.StringCollection"/> that contains all the dependent directory paths.</returns>
        /// <remarks>None.</remarks>
        private System.Collections.Specialized.StringCollection GetDependentDirectories(
            String parentDirectoryPath,
            System.Collections.Specialized.StringCollection dependentPaths)
        {
            // Get the collection of child directories
            String[] directories = System.IO.Directory.GetDirectories(parentDirectoryPath);

            // Loop through each child directory
            for (int loopIndex = 0; loopIndex < directories.Length; loopIndex++)
            {
                // Add the child directory as a dependency
                dependentPaths.Add(directories[loopIndex]);

                // Recursively get the child directories
                GetDependentDirectories(directories[loopIndex], dependentPaths);
            }

            // Return the collection of directories
            return dependentPaths;
        }

        /// <summary>
        /// Determines whether the virtual path represents the theme directory.
        /// </summary>
        /// <param name="virtualPath">The virtual path.</param>
        /// <returns><see langword="true"/> if the virtual path represents the theme directory; otherwise, <see langword="false"/>.</returns>
        /// <remarks>This method will return <see langword="false"/> if the virtual path represents a directory that is a descendent of the theme directory.</remarks>
        private Boolean IsThemeDirectoryVirtualPath(String virtualPath)
        {
            // Get the virtual path of the parent directory
            String parentVirtualPath = System.Web.VirtualPathUtility.GetDirectory(virtualPath);

            // Return whether the parent virtual path is the App_Themes directory
            return parentVirtualPath.EndsWith(ASPNetThemeBasePath, StringComparison.InvariantCultureIgnoreCase);
        }

        /// <summary>
        /// Gets the theme directory virtual path.
        /// </summary>
        /// <param name="virtualPath">The virtual path.</param>
        /// <returns>A <see cref="T:System.String"/> that contains the virtual path of the theme directory.</returns>
        /// <remarks>None.</remarks>
        private String GetThemeDirectoryVirtualPath(String virtualPath)
        {
            // Get the virtual path of the parent directory
            String parentVirtualPath = System.Web.VirtualPathUtility.GetDirectory(virtualPath);

            // Loop while the parent virtual path is not the theme directory virtual path
            while (IsThemeDirectoryVirtualPath(parentVirtualPath) == false)
            {
                // Get the next parent virtual path
                parentVirtualPath = System.Web.VirtualPathUtility.GetDirectory(parentVirtualPath);
            }

            // Return the theme directory virtual path
            return parentVirtualPath;
        }

        /// <summary>
        /// Gets the directory from the cache.
        /// </summary>
        /// <param name="virtualDirectoryPath">The virtual directory path.</param>
        /// <returns>A <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemeDirectory"/> instance. Returns <see langword="null"/> if the directory for the virtual path doesn't exist.</returns>
        /// <remarks>None.</remarks>
        private VirtualThemeDirectory GetDirectoryFromCache(
            String virtualDirectoryPath)
        {
            // Get the directory from the cache
            VirtualThemeDirectory directory = (VirtualThemeDirectory)System.Web.Hosting.HostingEnvironment.Cache[CacheKeyPrefix + virtualDirectoryPath];

            // Return the directory if it is in the cache
            if (directory != null)
                return directory;

            // Create the new directory
            directory = new VirtualThemeDirectory(virtualDirectoryPath);

            // Get the cache dependency for the item
            System.Web.Caching.CacheDependency dependency = GetCacheDependency(virtualDirectoryPath, null, DateTime.Now);

            // Store the item in the cache
            System.Web.Hosting.HostingEnvironment.Cache.Insert(CacheKeyPrefix + virtualDirectoryPath, directory, dependency);

            // Return the new directory
            return directory;
        }

        /// <summary>
        /// Converts the relative path to a relative path for the current theme.
        /// </summary>
        /// <param name="relativePath">The relative path.</param>
        /// <returns>The relative path for the current theme directory.</returns>
        /// <remarks>None.</remarks>
        internal String ConvertToThemeRelativePath(String relativePath)
        {
            // Convert the relative path to a relative path under the current theme directory
            return ConvertToThemeNameRelativePath(relativePath, false);
        }

        /// <summary>
        /// Converts the virtual path to a global relative path.
        /// </summary>
        /// <param name="relativePath">The relative path.</param>
        /// <returns>The relative path for the global theme directory.</returns>
        /// <remarks>None.</remarks>
        internal String ConvertToGlobalRelativePath(String relativePath)
        {
            // Convert the relative path to a relative path under the global theme directory
            return ConvertToThemeNameRelativePath(relativePath, true);
        }

        /// <summary>
        /// Converts a relative path to a relative path specific to either the global theme relative path or the current theme relative path.
        /// </summary>
        /// <param name="relativePath">The relative path.</param>
        /// <param name="replaceThemeNameWithGlobal">If set to <see langword="true"/>, the global theme name is used, otherwise the current theme name is used.</param>
        /// <returns>The relative path converted to be relative to either the global or current theme directory.</returns>
        /// <remarks>None.</remarks>
        private String ConvertToThemeNameRelativePath(String relativePath, Boolean replaceThemeNameWithGlobal)
        {
            // Create the return value
            String themeNameRelativePath = String.Empty;

            // Check if there is any relative path information before the App_Themes directory
            if ((relativePath.StartsWith(ASPNetThemeBasePath) == false)
                && (ThemeRelativePath.StartsWith("/") == false))
            {
                // Add the relative path prefix
                themeNameRelativePath = relativePath.Substring(0, relativePath.IndexOf(ASPNetThemeBasePath));
            }

            // Check if a / needs to be added
            if ((themeNameRelativePath.EndsWith("/") == false)
                && (ThemeRelativePath.StartsWith("/") == false))
            {
                // The relative path built so far doesn't end with / and the themes relative path doesn't start with /
                // We need to add / before we combine them
                themeNameRelativePath = System.Web.VirtualPathUtility.AppendTrailingSlash(themeNameRelativePath);
            }

            // Add the custom theme relative path
            themeNameRelativePath += ThemeRelativePath;

            // Calculate the remainder of the path value
            String remainderPath = relativePath.Substring(relativePath.IndexOf(ASPNetThemeBasePath) + ASPNetThemeBasePath.Length);

            // Check if the global theme name should be used rather than the current theme name
            // The path should already contain the current theme name
            if (replaceThemeNameWithGlobal == true)
            {
                // Replace the theme name with the Global theme name
                remainderPath = GlobalThemeName + remainderPath.Substring(remainderPath.IndexOf("/"));
            }

            // Add the additional path information
            themeNameRelativePath += remainderPath;

            // Return the calculated value
            return themeNameRelativePath;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets the current <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemePathProvider"/> singleton instance.
        /// </summary>
        /// <value>The current provider instance.</value>
        /// <remarks>None.</remarks>
        public static VirtualThemePathProvider Current
        {
            get
            {
                // Return the cached provider if it has already been created
                if (_currentProvider != null)
                    return _currentProvider;

                // Create and store the new provider
                _currentProvider = new VirtualThemePathProvider();

                // Return the created provider
                return _currentProvider;
            }
        }

        /// <summary>
        /// Gets the state scope.
        /// </summary>
        /// <value>The state scope.</value>
        /// <remarks>None.</remarks>
        private String StateScope
        {
            get
            {
                // Return the stored value if it has already been determined
                if (_stateScope != null)
                    return _stateScope;

                // Attempt to load the value from web.config
                String settingsValue = System.Configuration.ConfigurationManager.AppSettings[StateScopeKey];

                // Store the state scope value as the value found in the config if it is valid
                // otherwise store the default state scope
                if ((String.IsNullOrEmpty(settingsValue) == false)
                    && (settingsValue.ToUpper() == ApplicationStateScopeName.ToUpper()))
                    _stateScope = ApplicationStateScopeName;
                else
                    _stateScope = DefaultStateScope;

                // Return the stored value
                return _stateScope;
            }
        }

        /// <summary>
        /// Gets the default filter set to apply.
        /// </summary>
        /// <value>The default filter set to apply.</value>
        /// <remarks>None.</remarks>
        public String DefaultSet
        {
            get
            {
                // Return the stored value if it has already been determined
                if (_defaultSet != null)
                    return _defaultSet;

                // Get the value from web.config
                String settingsValue = System.Configuration.ConfigurationManager.AppSettings[DefaultSetKey];

                // Store the config value if it exists, otherwise store the default value
                if (String.IsNullOrEmpty(settingsValue) == false)
                    _defaultSet = settingsValue;
                else
                    _defaultSet = DefaultSetValue;
                
                // Return the stored value
                return _defaultSet;
            }
        }

        /// <summary>
        /// Gets or sets the current set.
        /// </summary>
        /// <value>The current set.</value>
        /// <remarks>
        /// <para>
        /// When filtering is determined for the contents of a <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemeDirectory" />,
        /// this value is used to find a <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterSet" /> 
        /// in the <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDefinition" /> if one exists in the theme or global directory.
        /// </para>
        /// <para>
        /// This value can be stored for each user or stored at the application level. By default, the value is stored for each user.
        /// This behaviour can be changed by adding an application setting into the <c>web.config</c> file with 
        /// the key of <c>VirtualThemePathProviderStateScope</c> 
        /// and the value of <c>Application</c>.
        /// When the value is stored for each user, the value is persisted in an <see cref="T:System.Web.HttpCookie"/>.</para>
        /// </remarks>
        public String CurrentSet
        {
            get
            {
                String returnValue = String.Empty;

                // Check if the state scope is user or application
                if (StateScope == UserStateScopeName)
                {
                    // The state scope is user
                    // State value needs to be stored in cookies because sessions are rarely available

                    HttpCookie cookieValue = null;
                    
                    // Check whether there is a request object that has cookies available
                    if ((HttpContext.Current != null)
                        && (HttpContext.Current.Request != null)
                        && (HttpContext.Current.Request.Cookies != null))
                    {
                        // Get the cookie value for the current request
                        cookieValue = HttpContext.Current.Request.Cookies[CookieStateScopeKey];
                    }

                    // Check if a cookie was found
                    // If no cookie is found, the default set is returned, otherwise the cookie value is returned
                    if (cookieValue == null)
                        returnValue = DefaultSet;
                    else
                        returnValue = cookieValue.Value;
                }
                else
                {
                    // The state scope is application

                    // Check if the current set is defined
                    // If the set is not defined, the default set is returned, otherwise the stored value is returned
                    if (_currentApplicationSet == null)
                        returnValue = DefaultSet;
                    else
                        returnValue = _currentApplicationSet;
                }

                // Ensure that null can never be returned
                return returnValue ?? String.Empty;
            }
            set
            {
                if (StateScope == UserStateScopeName)
                {
                    if ((HttpContext.Current != null)
                        && (HttpContext.Current.Response != null)
                        && (HttpContext.Current.Response.Cookies != null))
                    {
                        HttpCookie cookieValue = new HttpCookie(CookieStateScopeKey, value);
                        
                        // Set the expiry date of the cookie to a year from now
                        cookieValue.Expires = System.DateTime.Now.AddYears(1);

                        HttpContext.Current.Response.Cookies.Add(cookieValue);
                        HttpContext.Current.Request.Cookies[CookieStateScopeKey].Value = value;
                    }
                }
                else
                {
                    _currentApplicationSet = value;
                }
            }
        }

        /// <summary>
        /// Gets the theme relative path.
        /// </summary>
        /// <value>The theme relative path.</value>
        /// <remarks>
        /// The theme relative path is the relative path to the directory that contains the theme directories.
        /// This directory is the same concept as the <c>App_Themes</c> directory, but allows the themes to be stored in a different place.
        /// </remarks>
        private String ThemeRelativePath
        {
            get
            {
                // Check if the relative path to the theme directory has already been determined
                if (String.IsNullOrEmpty(_themeRelativePath) == false)
                    return _themeRelativePath;

                // Get the relative path from the application settings
                _themeRelativePath = System.Configuration.ConfigurationManager.AppSettings[ThemeRelativePathKey];

                // Check if the application settings stored the relative path value
                // If the application settings didn't store the value, the default value is used
                if (String.IsNullOrEmpty(_themeRelativePath) == true)
                    _themeRelativePath = DefaultThemeRelativePath;
                
                // Ensure that the relative path ends with /
                _themeRelativePath = System.Web.VirtualPathUtility.AppendTrailingSlash(_themeRelativePath);

                // Return the relative path
                return _themeRelativePath;
            }
        }

        /// <summary>
        /// Gets the name of the global theme.
        /// </summary>
        /// <value>The name of the global theme.</value>
        /// <remarks>None.</remarks>
        /// <exception cref="T:Neovolve.VirtualThemeProvider.Exceptions.InvalidFilterFileDefinitionException">
        /// Thrown when the global theme name found in the application settings contains the / character.
        /// </exception>
        private String GlobalThemeName
        {
            get
            {
                // Return the global theme name if it has already been determined
                if (String.IsNullOrEmpty(_globalThemeName) == false)
                    return _globalThemeName;

                // Get the global name from the application settings
                _globalThemeName = System.Configuration.ConfigurationManager.AppSettings[GlobalThemeNameKey];

                // Check if the application settings stored the value. If not, store the default global name
                if (String.IsNullOrEmpty(_globalThemeName) == true)
                    _globalThemeName = DefaultGlobalThemeName;

                // Ensure that the global theme name doesn't contain / characters
                if (_globalThemeName.Contains("/") == true)
                    throw new Exceptions.InvalidConfigurationException("GlobalThemeName", "The global theme name can't contain / characters.");

                // Return the stored global name
                return _globalThemeName;
            }
        }

        #endregion
    }
}
