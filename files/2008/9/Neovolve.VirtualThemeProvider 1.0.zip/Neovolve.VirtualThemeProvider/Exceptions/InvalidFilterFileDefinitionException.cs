using System;
using System.Collections.Generic;
using System.Text;

namespace Neovolve.VirtualThemeProvider.Exceptions
{
    /// <summary>
    /// The <see cref="T:Neovolve.VirtualThemeProvider.Exceptions.InvalidFilterDefinitionException"/> 
    /// describes the exception condition where the file name defined as a filter is invalid.
    /// </summary>
    /// <remarks>None.</remarks>
    public class InvalidFilterFileDefinitionException : System.ApplicationException
    {
        #region Declarations

        /// <summary>
        /// Defines the message format for the <see cref="P:Neovolve.VirtualThemeProvider.ExceptionsSchemaValidationFailedException.Message"/> property.
        /// </summary>
        /// <remarks>None.</remarks>
        private const String MessageFormat = "File {0} specified in the filter set {1} in the filter definition {2} is invalid.";

        /// <summary>
        /// Stores the name of the filter file in the filter definition.
        /// </summary>
        /// <remarks>None.</remarks>
        private String _filterFileName;

        /// <summary>
        /// Stores the name of the filter set in the filter definition
        /// </summary>
        /// <remarks>None.</remarks>
        private String _filterSetName;

        /// <summary>
        /// Stores the file path of the filter definition.
        /// </summary>
        /// <remarks>None.</remarks>
        private String _filterDefinitionFilePath;

        /// <summary>
        /// Stores any additional information supplied.
        /// </summary>
        /// <remarks>None.</remarks>
        private String _additionalInformation;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="T:Neovolve.VirtualThemeProvider.Exceptions.InvalidFilterFileDefinitionException"/> class.
        /// </summary>
        /// <param name="filterFileName">Name of the filter file.</param>
        /// <param name="filterSetName">Name of the filter set.</param>
        /// <param name="filterDefinitionFilePath">The filter definition file path.</param>
        /// <remarks>None.</remarks>
        public InvalidFilterFileDefinitionException(String filterFileName, String filterSetName, String filterDefinitionFilePath)
            : this(filterFileName, filterSetName, filterDefinitionFilePath, String.Empty)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="T:Neovolve.VirtualThemeProvider.Exceptions.InvalidFilterFileDefinitionException"/> class.
        /// </summary>
        /// <param name="filterFileName">Name of the filter file.</param>
        /// <param name="filterSetName">Name of the filter set.</param>
        /// <param name="filterDefinitionFilePath">The filter definition file path.</param>
        /// <param name="additionalInformation">The additional information.</param>
        /// <remarks>None.</remarks>
        public InvalidFilterFileDefinitionException(String filterFileName, String filterSetName, String filterDefinitionFilePath, String additionalInformation)
        {
            _filterFileName = filterFileName;
            _filterSetName = filterSetName;
            _filterDefinitionFilePath = filterDefinitionFilePath;
            _additionalInformation = additionalInformation;
        }
		 
	    #endregion

        #region Properties

        /// <summary>
        /// Gets a message that describes the current exception.
        /// </summary>
        /// <returns>The error message that explains the reason for the exception.</returns>
        /// <remarks>None.</remarks>
        public override string Message
        {
            get
            {
                // Build the base message
                String messageValue = String.Format(MessageFormat, _filterFileName, _filterSetName, _filterDefinitionFilePath);

                // Append any additional information
                if (String.IsNullOrEmpty(_additionalInformation) == false)
                    messageValue += " " + _additionalInformation;

                // Return the message
                return messageValue;
            }
        }

        /// <summary>
        /// Gets the name of the filter file.
        /// </summary>
        /// <value>The name of the filter file.</value>
        /// <remarks>None.</remarks>
        public String FilterFileName
        {
            get
            {
                return _filterFileName;
            }
        }

        /// <summary>
        /// Gets the name of the filter set.
        /// </summary>
        /// <value>The name of the filter set.</value>
        /// <remarks>None.</remarks>
        public String FilterSetName
        {
            get
            {
                return _filterSetName;
            }
        }

        /// <summary>
        /// Gets the filter definition file path.
        /// </summary>
        /// <value>The filter definition file path.</value>
        /// <remarks>None.</remarks>
        public String FilterDefinitionFilePath
        {
            get
            {
                return _filterDefinitionFilePath;
            }
        }

	    #endregion
    }
}
