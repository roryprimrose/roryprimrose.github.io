using System;
using System.Collections.Generic;
using System.Text;

namespace Neovolve.VirtualThemeProvider.Exceptions
{
    /// <summary>
    /// The <see cref="T:Neovolve.VirtualThemeProvider.Exceptions.InvalidFilterDefinitionException"/> 
    /// describes the exception condition where a configuration value has been defined but its value is invalid.
    /// </summary>
    /// <remarks>None.</remarks>
    public class InvalidConfigurationException : System.ApplicationException
    {
        #region Declarations

        /// <summary>
        /// Defines the message format for the <see cref="P:Neovolve.VirtualThemeProvider.ExceptionsSchemaValidationFailedException.Message"/> property.
        /// </summary>
        /// <remarks>None.</remarks>
        private const String MessageFormat = "Invalid configuration value specified for {0}.";

        /// <summary>
        /// Stores the name of the configuration item.
        /// </summary>
        /// <remarks>None.</remarks>
        private String _configurationName;

        /// <summary>
        /// Stores any additional information supplied.
        /// </summary>
        /// <remarks>None.</remarks>
        private String _additionalInformation;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="T:Neovolve.VirtualThemeProvider.Exceptions.InvalidConfigurationException"/> class.
        /// </summary>
        /// <param name="configurationName">Name of the configuration.</param>
        /// <remarks>None.</remarks>
        public InvalidConfigurationException(String configurationName)
            : this(configurationName, String.Empty)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="T:Neovolve.VirtualThemeProvider.Exceptions.InvalidConfigurationException"/> class.
        /// </summary>
        /// <param name="configurationName">Name of the configuration.</param>
        /// <param name="additionalInformation">The additional information.</param>
        /// <remarks>None.</remarks>
        public InvalidConfigurationException(String configurationName, String additionalInformation)
        {
            _configurationName = configurationName;
            _additionalInformation = additionalInformation;
        }
		 
	    #endregion

        #region Properties

        /// <summary>
        /// Gets a message that describes the current exception.
        /// </summary>
        /// <returns>The error message that explains the reason for the exception.</returns>
        /// <remarks>None.</remarks>
        public override string Message
        {
            get
            {
                // Build the base message
                String messageValue = String.Format(MessageFormat, _configurationName);

                // Append any additional information
                if (String.IsNullOrEmpty(_additionalInformation) == false)
                    messageValue += " " + _additionalInformation;

                // Return the message
                return messageValue;
            }
        }

        /// <summary>
        /// Gets the name of the configuration.
        /// </summary>
        /// <value>The name of the configuration.</value>
        /// <remarks>None.</remarks>
        public String ConfigurationName
        {
            get
            {
                return _configurationName;
            }
        }

	    #endregion
    }
}
