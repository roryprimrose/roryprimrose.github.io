using System;
using System.Collections.Generic;
using System.Text;

namespace Neovolve.VirtualThemeProvider.Exceptions
{
    /// <summary>
    /// The <see cref="T:Neovolve.VirtualThemeProvider.Exceptions.SchemaValidationFailedException"/> 
    /// describes the exception condition where an xml document has failed validation against an xml schema.
    /// </summary>
    /// <remarks>None.</remarks>
    public class SchemaValidationFailedException : System.ApplicationException
    {
        #region Declarations

        /// <summary>
        /// Defines the message format for the <see cref="P:Neovolve.VirtualThemeProvider.ExceptionsSchemaValidationFailedException.Message"/> property.
        /// </summary>
        /// <remarks>None.</remarks>
        private const String MessageFormat = "XML data found in {0} does not conform to the schema required. {1}";

        /// <summary>
        /// Stores the file path of the xml file that failed validation.
        /// </summary>
        /// <remarks>None.</remarks>
        private String _filePath;

        /// <summary>
        /// Stores the errors encountered when validating the xml document.
        /// </summary>
        /// <remarks>None.</remarks>
        private String _schemaErrors;
        
        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="T:Neovolve.VirtualThemeProvider.Exceptions.SchemaValidationFailedException"/> class.
        /// </summary>
        /// <param name="filePath">The file path.</param>
        /// <param name="schemaErrors">The schema errors.</param>
        /// <remarks>None.</remarks>
        public SchemaValidationFailedException(String filePath, String schemaErrors)
        {
            _filePath = filePath;
            _schemaErrors = schemaErrors;
        }
		 
	    #endregion

        #region Properties

        /// <summary>
        /// Gets a message that describes the current exception.
        /// </summary>
        /// <returns>The error message that explains the reason for the exception.</returns>
        /// <remarks>None.</remarks>
        public override string Message
        {
            get
            {
                return String.Format(MessageFormat, _filePath, _schemaErrors);
            }
        }
		 
	    #endregion
    }
}
