using System;
using System.Collections.Generic;
using System.Text;

namespace Neovolve.VirtualThemeProvider.Exceptions
{
#if DEBUG
    /// <summary>
    /// The Neovolve.VirtualThemeProvider.Exceptions namespace provides the set of exceptions specific to the VirtualThemeProvider.
    /// </summary>
    /// <remarks>None.</remarks>
    public class NamespaceDoc
    {
    }
#endif
}
