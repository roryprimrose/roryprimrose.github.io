using System;
using System.Collections.Generic;
using System.Text;

namespace Neovolve.VirtualThemeProvider
{
#if DEBUG
    /// <summary>
    /// <para>
    /// The Neovolve.VirtualThemeProvider namespace provides functionality for flexible ASP.Net theme support. This support includes theme directory merging and filtering.
    /// </para>
    /// <para>
    /// Theme directories will be merged with global theme directories. Directory files and subdirectories will be merged into the virtual directory
    /// where they share the same path relative to the theme and global directory. 
    /// </para>
    /// <para>
    /// Files and directories can be filtered from the current request by defining filter sets. Filter sets are defined in <c>VirtualThemePathFilters.config</c> files 
    /// that are located in each physical directory that requires filtering.
    /// </para>
    /// <para>
    /// To get the best overview of how implement the <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemePathProvider"/>, refer to the Remarks section of 
    /// <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemePathProvider"/>, <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDefinition"/>
    /// and <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterSet"/>.
    /// </para>
    /// </summary>
    /// <seealso cref="T:Neovolve.VirtualThemeProvider.VirtualThemePathProvider">Neovolve.VirtualThemeProvider.VirtualThemePathProvider</seealso>
    /// <seealso cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDefinition">Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDefinition</seealso>
    /// <seealso cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterSet">Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterSet</seealso>
    public class NamespaceDoc
    {
    }
#endif
}
