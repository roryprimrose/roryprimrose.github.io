using System;
using System.Collections.Generic;
using System.Text;
using System.Web;

namespace Neovolve.VirtualThemeProvider
{
    /// <summary>
    /// The <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemeDirectory"/> class contains information about a virtual directory. 
    /// It loads all the possible files and directories and exposes those items that are available given the current filter set.
    /// </summary>
    /// <remarks>None.</remarks>
    public class VirtualThemeDirectory : System.Web.Hosting.VirtualDirectory
    {
        #region Declarations

        /// <summary>
        /// Stores information about a virtual file or directory.
        /// </summary>
        /// <remarks>None.</remarks>
        private struct ItemSearchInfo
        {
            /// <summary>
            /// Stores the name of the item.
            /// </summary>
            /// <remarks>None.</remarks>
            public String Name;

            /// <summary>
            /// Stores the virtual path for the item.
            /// </summary>
            /// <remarks>None.</remarks>
            public String VirtualPath;

            /// <summary>
            /// Stores the absolute path for the item in the theme directory.
            /// </summary>
            /// <remarks>This value will be <see cref="F:System.String.Empty">String.Empty</see> if the item doesn't exist in the theme directory.</remarks>
            public String ThemeAbsolutePath;

            /// <summary>
            /// Stores the absolute path for the item in the global directory.
            /// </summary>
            /// <remarks>This value will be <see cref="F:System.String.Empty">String.Empty</see> if the item doesn't exist in the global directory.</remarks>
            public String GlobalAbsolutePath;
        }

        /// <summary>
        /// Stores the parent <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemeDirectory"/>.
        /// </summary>
        /// <remarks>None.</remarks>
        private VirtualThemeDirectory _parent = null;

        /// <summary>
        /// Stores the absolute path to the theme directory.
        /// </summary>
        /// <remarks>None.</remarks>
        private String _themeAbsolutePath = String.Empty;

        /// <summary>
        /// Stores the absolute path to the global directory.
        /// </summary>
        /// <remarks>None.</remarks>
        private String _globalAbsolutePath = String.Empty;

        /// <summary>
        /// Stores the absolute path to the filter definition file found in the theme directory.
        /// </summary>
        /// <remarks>None.</remarks>
        private String _themeFilterDefinitionAbsolutePath = null;

        /// <summary>
        /// Stores the absolute path to the filter definition file found in the global directory.
        /// </summary>
        /// <remarks>None.</remarks>
        private String _globalFilterDefinitionAbsolutePath = null;

        /// <summary>
        /// Stores the directories that exist in the theme and global directories.
        /// </summary>
        /// <remarks>None.</remarks>
        private Dictionary<String, VirtualThemeDirectory> _directories = null;

        /// <summary>
        /// Stores the files that exist in the theme and global directories.
        /// </summary>
        /// <remarks>None.</remarks>
        private Dictionary<String, VirtualThemeFile> _files = null;

        /// <summary>
        /// Stores the files and directories that exist in the theme and global directories.
        /// </summary>
        /// <remarks>None.</remarks>
        private Dictionary<String, System.Web.Hosting.VirtualFileBase> _children = null;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemeDirectory"/> class.
        /// </summary>
        /// <param name="virtualPath">The virtual path to the resource represented by this instance.</param>
        /// <remarks>None.</remarks>
        public VirtualThemeDirectory(String virtualPath)
            : this(virtualPath, String.Empty, String.Empty, null)
        {            
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemeDirectory"/> class.
        /// </summary>
        /// <param name="virtualPath">The virtual path.</param>
        /// <param name="themeAbsolutePath">The absolute path to the theme directory.</param>
        /// <param name="globalAbsolutePath">The absolute path to the global directory.</param>
        /// <remarks>None.</remarks>
        public VirtualThemeDirectory(String virtualPath,
            String themeAbsolutePath,
            String globalAbsolutePath)
            : this(virtualPath, themeAbsolutePath, globalAbsolutePath, null)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemeDirectory"/> class.
        /// </summary>
        /// <param name="virtualPath">The virtual path.</param>
        /// <param name="themeAbsolutePath">The absolute path to the theme directory.</param>
        /// <param name="globalAbsolutePath">The absolute path to the global directory.</param>
        /// <param name="parent">The parent <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemeDirectory"/>.</param>
        /// <remarks>None.</remarks>
        public VirtualThemeDirectory(String virtualPath,
            String themeAbsolutePath,
            String globalAbsolutePath, 
            VirtualThemeDirectory parent)
            : base(virtualPath)
        {
            // Get the abosolute paths if they haven't been provided

            // Calculate the theme absolute path if it isn't provided
            if (String.IsNullOrEmpty(themeAbsolutePath) == true)
            {
                // Get the relative path for the theme directory
                String sThemeRelativePath = VirtualThemePathProvider.Current.ConvertToThemeRelativePath(VirtualPath);

                // Convert the relative path into an absolute path
                themeAbsolutePath = HttpContext.Current.Server.MapPath(sThemeRelativePath);
            }

            // Check if the theme directory exists
            if (System.IO.Directory.Exists(themeAbsolutePath) == false)
                themeAbsolutePath = String.Empty;

            // Calculate the global absolute path if it isn't provided
            if (String.IsNullOrEmpty(globalAbsolutePath) == true)
            {
                // Get the relative path for the global theme directory
                String sGlobalRelativePath = VirtualThemePathProvider.Current.ConvertToGlobalRelativePath(virtualPath);

                // Convert the relative path into an absolute path
                globalAbsolutePath = HttpContext.Current.Server.MapPath(sGlobalRelativePath);
            }

            // Check if the global directory exists
            if (System.IO.Directory.Exists(globalAbsolutePath) == false)
                globalAbsolutePath = String.Empty;

            // Store the absolute paths
            _themeAbsolutePath = themeAbsolutePath;
            _globalAbsolutePath = globalAbsolutePath;

            // Assign the parent directory value
            _parent = parent;

            // Create the collections to hold the virtual items
            _files = new Dictionary<string, VirtualThemeFile>();
            _directories = new Dictionary<string, VirtualThemeDirectory>();
            _children = new Dictionary<string, System.Web.Hosting.VirtualFileBase>();

            // Determine the list of files in the theme and global directories
            FindFiles();

            // Determine the set of directories, merged for the global and theme directories
            FindSubDirectories();

            // Populate the children collection with all the files and subdirectories
            FindChildren();
        }
        
        #endregion

        #region Methods

        /// <summary>
        /// Finds the files.
        /// </summary>
        /// <remarks>None.</remarks>
        private void FindFiles()
        {
            // Create a list of file information items that will be used to create the dictionary of files
            Dictionary<String, ItemSearchInfo> fileList = new Dictionary<string, ItemSearchInfo>();

            // Check if the theme directory exists
            if (System.IO.Directory.Exists(ThemeAbsolutePath) == true)
            {
                // Get a list of the files in the directory
                String[] files = System.IO.Directory.GetFiles(ThemeAbsolutePath);

                // Loop through each file found in the directory
                for (int loopIndex = 0; loopIndex < files.Length; loopIndex++)
                {
                    ItemSearchInfo fileInfo = new ItemSearchInfo();

                    // Get the name of the file
                    fileInfo.Name = System.IO.Path.GetFileName(files[loopIndex]);

                    // Check if the filename is a filter definition file
                    if (fileInfo.Name.ToUpper() != VirtualThemePathProvider.FilterDefinitionFileName.ToUpper())
                    {
                        // Determine the virtual path for this file
                        fileInfo.VirtualPath = System.Web.VirtualPathUtility.Combine(VirtualPath, fileInfo.Name);
                        fileInfo.ThemeAbsolutePath = files[loopIndex];

                        // Add the file to the files list
                        fileList.Add(fileInfo.Name, fileInfo);
                    }
                    else
                    {
                        // Store the absolute path to the theme filter definition
                        _themeFilterDefinitionAbsolutePath = files[loopIndex];
                    }
                }
            }

            // Check if the global directory exists
            if (System.IO.Directory.Exists(GlobalAbsolutePath) == true)
            {
                // Get a list of the files in the directory
                String[] files = System.IO.Directory.GetFiles(GlobalAbsolutePath);

                // Loop through each file found in the directory
                for (int loopIndex = 0; loopIndex < files.Length; loopIndex++)
                {
                    ItemSearchInfo fileInfo = new ItemSearchInfo();

                    // Get the name of the file
                    fileInfo.Name = System.IO.Path.GetFileName(files[loopIndex]);

                    // Check if the filename is a filter definition file
                    if (fileInfo.Name.ToUpper() == VirtualThemePathProvider.FilterDefinitionFileName.ToUpper())
                    {
                        // Store the absolute path to the global filter definition
                        _globalFilterDefinitionAbsolutePath = files[loopIndex];
                    }
                    else if (fileList.ContainsKey(fileInfo.Name) == true)
                    {
                        // This file also existed in the theme directory
                        ItemSearchInfo themeFileInfo = fileList[fileInfo.Name];

                        // Remove the original item
                        fileList.Remove(themeFileInfo.Name);

                        // Store the global absolute path
                        themeFileInfo.GlobalAbsolutePath = files[loopIndex];

                        // Add the new value
                        fileList.Add(themeFileInfo.Name, themeFileInfo);
                    }
                    else
                    {
                        // Determine the virtual path for this file
                        fileInfo.VirtualPath = System.Web.VirtualPathUtility.Combine(VirtualPath, fileInfo.Name);
                        fileInfo.GlobalAbsolutePath = files[loopIndex];

                        // Add the file to the files list
                        fileList.Add(fileInfo.Name, fileInfo);
                    }
                }
            }

            // Loop through each file found
            foreach (ItemSearchInfo fileInfo in fileList.Values)
            {
                // Add each file to the files dictionary using the information stored for the file
                _files.Add(fileInfo.Name, new VirtualThemeFile(fileInfo.VirtualPath, fileInfo.ThemeAbsolutePath, fileInfo.GlobalAbsolutePath, this));
            }
        }

        /// <summary>
        /// Finds the subdirectories.
        /// </summary>
        /// <remarks>None.</remarks>
        private void FindSubDirectories()
        {
            // Create a list of directory information items that will be used to create the dictionary of directories
            Dictionary<String, ItemSearchInfo> directoryList = new Dictionary<string, ItemSearchInfo>();

            // Check if the theme directory exists
            if (System.IO.Directory.Exists(ThemeAbsolutePath) == true)
            {
                // Get the list of the directories in the theme directory
                String[] themeDirectories = System.IO.Directory.GetDirectories(ThemeAbsolutePath);

                // Loop through each directory found in the theme directory
                for (int loopIndex = 0; loopIndex < themeDirectories.Length; loopIndex++)
                {
                    ItemSearchInfo directoryInfo = new ItemSearchInfo();

                    // Get the name of the directory
                    directoryInfo.Name = System.IO.Path.GetFileName(themeDirectories[loopIndex]);

                    // Determine the virtual path for this directory
                    directoryInfo.VirtualPath = System.Web.VirtualPathUtility.Combine(VirtualPath, directoryInfo.Name);

                    // Ensure that the path ends with a trailing forward slash
                    directoryInfo.VirtualPath = System.Web.VirtualPathUtility.AppendTrailingSlash(directoryInfo.VirtualPath);

                    directoryInfo.ThemeAbsolutePath = themeDirectories[loopIndex];

                    // Add the directory to the directories list
                    directoryList.Add(directoryInfo.Name, directoryInfo);
                }
            }

            // Check if the global directory exists
            if (System.IO.Directory.Exists(GlobalAbsolutePath) == true)
            {
                // Get the list of the directories in the global directory
                String[] globalDirectories = System.IO.Directory.GetDirectories(GlobalAbsolutePath);

                // Loop through each directory found in the global directory
                for (int loopIndex = 0; loopIndex < globalDirectories.Length; loopIndex++)
                {
                    ItemSearchInfo directoryInfo = new ItemSearchInfo();

                    // Store the name of the directory
                    directoryInfo.Name = System.IO.Path.GetFileName(globalDirectories[loopIndex]);

                    // Check whether the directory already exists in the list
                    if (directoryList.ContainsKey(directoryInfo.Name) == true)
                    {
                        ItemSearchInfo themeDirectoryInfo = directoryList[directoryInfo.Name];

                        // Remove the original value
                        directoryList.Remove(themeDirectoryInfo.Name);

                        // Store the global absolute path
                        themeDirectoryInfo.GlobalAbsolutePath = globalDirectories[loopIndex];

                        // Store the new value
                        directoryList.Add(themeDirectoryInfo.Name, themeDirectoryInfo);
                    }
                    else
                    {
                        // Store the virtual path for the directory
                        directoryInfo.VirtualPath = System.Web.VirtualPathUtility.Combine(VirtualPath, directoryInfo.Name);

                        // Ensure that the path ends with a trailing forward slash
                        directoryInfo.VirtualPath = System.Web.VirtualPathUtility.AppendTrailingSlash(directoryInfo.VirtualPath);

                        // Store the global absolute path
                        directoryInfo.GlobalAbsolutePath = globalDirectories[loopIndex];

                        // Add the directory to the directories list
                        directoryList.Add(directoryInfo.Name, directoryInfo);
                    }
                }
            }

            // Loop through each directory found
            foreach (ItemSearchInfo directoryInfo in directoryList.Values)
            {
                // Create the new directory
                VirtualThemeDirectory directory = new VirtualThemeDirectory(directoryInfo.VirtualPath, directoryInfo.ThemeAbsolutePath, directoryInfo.GlobalAbsolutePath, this);

                // Add the directory to the dictionary
                _directories.Add(directory.Name, directory);
            }
        }

        /// <summary>
        /// Finds the children.
        /// </summary>
        /// <remarks>None.</remarks>
        private void FindChildren()
        {
            // Loop through each directory
            foreach (VirtualThemeDirectory directory in Directories)
            {
                // Add the directory to the childrens dictionary
                _children.Add(directory.Name, directory);
            }

            // Loop through each file
            foreach (VirtualThemeFile file in Files)
            {
                // Add the file to the childrens dictionary
                _children.Add(file.Name, file);
            }
        }

        #endregion

        #region Functions

        /// <summary>
        /// Gets whether the file included for the current set.
        /// </summary>
        /// <param name="fileName">Name of the file.</param>
        /// <returns><see langword="true"/> if the file is included, otherwise <see langword="false"/>.</returns>
        /// <remarks>
        /// <para>Skin files are always included because the <see cref="M:System.Web.Hosting.VirtualPathProvider.FileExists"/> method only gets called once for skin files.
        /// This means that there is only one opportunity to indicate whether the skin file is available. Other files, such as css files, will be queried on each request
        /// for whether they exist.</para>
        /// <para>Files that exist and are not filtered in the theme directory will take precedence over directories that exist and are not filtered in the global directory.</para>
        /// </remarks>
        public Boolean GetFileIsIncluded(String fileName)
        {
            // Get the current set value
            String currentSet = VirtualThemePathProvider.Current.CurrentSet;

            // Check if the file is included in the theme directory
            // The theme directory takes precedence over the global directory
            if (FileIsIncluded(fileName, currentSet, true) == true)
            {
                // The file is included in the theme directory for the current filter set, return true
                return true;
            }
            else
            {
                // The file is not included in the theme directory for the current filter set

                // Return whether the global directory contains the file and allows it to be included for the current filter set
                return FileIsIncluded(fileName, currentSet, false);
            }
        }

        /// <summary>
        /// Gets whether the directory included for the current set.
        /// </summary>
        /// <param name="directoryName">Name of the directory.</param>
        /// <returns><see langword="true"/> if the directory is included, otherwise <see langword="false"/>.</returns>
        /// <remarks>
        /// Directories that exist and are not filtered in the theme directory will take precedence over directories that exist and are not filtered in the global directory.
        /// </remarks>
        public Boolean GetDirectoryIsIncluded(String directoryName)
        {
            // Get the current set value
            String currentSet = VirtualThemePathProvider.Current.CurrentSet;

            // Check if the directory is included in the theme directory
            // The theme directory takes precedence over the global directory
            if (DirectoryIsIncluded(directoryName, currentSet, true) == true)
            {
                // The directory is included in the theme directory for the current filter set, return true
                return true;
            }
            else
            {
                // The directory is not included in the theme directory for the current filter set

                // Return whether the global directory contains the directory and allows it to be included for the current filter set
                return DirectoryIsIncluded(directoryName, currentSet, false);
            }
        }

        /// <summary>
        /// Returns whether the file is included in the current filter set.
        /// </summary>
        /// <param name="fileName">The file name.</param>
        /// <param name="currentSet">The name of the current filter set.</param>
        /// <param name="checkAgainstTheme">If set to <see langword="true"/> the check is made against the theme filter set, otherwise the check is made against the global filter set.</param>
        /// <returns><see langword="true"/> if the file is included, otherwise <see langword="false"/>.</returns>
        /// <remarks>None.</remarks>
        internal Boolean FileIsIncluded(String fileName, String currentSet, Boolean checkAgainstTheme)
        {
            // Check whether the file exists in the dictionary
            if (_files.ContainsKey(fileName) == false)
                return false;

            // Get the file in question
            VirtualThemeFile file = _files[fileName];

            // Check if the file exists in the directory being checked against
            if ((checkAgainstTheme == true)
                && (file.ExistsInThemeDirectory == false))
            {
                // We are checking against the theme directory, but the file doesn't exist in the theme directory
                return false;
            }
            else if ((checkAgainstTheme == false)
                && (file.ExistsInGlobalDirectory == false))
            {
                // We are checking against the global directory, but the file doesn't exist in the global directory
                return false;
            }

            // Check if there is a set value to reference
            // If there is no set value, no filters can be applied so the item must be included
            if (String.IsNullOrEmpty(currentSet) == true)
                return true;

            // The file exists physically in either the theme and/or global directories

            // Get the extension of the file
            String fileExtension = System.IO.Path.GetExtension(fileName);

            // Check if the file is a skin file
            if (fileExtension.ToUpper() == ".SKIN")
            {
                // Skin files are always included
                return true;
            }

            // Return whether the file should be included
            return IncludeItem(fileName, currentSet, checkAgainstTheme, false);
        }

        /// <summary>
        /// Returns whether the directory is included in the current filter set.
        /// </summary>
        /// <param name="directoryName">The directory name.</param>
        /// <param name="currentSet">The name of the current filter set.</param>
        /// <param name="checkAgainstTheme">If set to <see langword="true"/>, the check is made against the theme directory.
        /// If <see langword="false"/>, the check is made against the global directory.</param>
        /// <returns><see langword="true"/> if the directory is included, otherwise <see langword="false"/>.</returns>
        /// <remarks>None.</remarks>
        internal Boolean DirectoryIsIncluded(String directoryName, String currentSet, Boolean checkAgainstTheme)
        {
            // Check if the directories list contains the directory name
            if (_directories.ContainsKey(directoryName) == false)
                return false;

            // The directory exists physically in either the theme and/or global directories

            // Get the directory in question
            VirtualThemeDirectory directory = _directories[directoryName];

            // Check if the directory exists in the directory being checked against
            if ((checkAgainstTheme == true)
                && (directory.ExistsInThemeDirectory == false))
            {
                // We are checking against the theme directory, but the directory doesn't exist in the theme directory
                return false;
            }
            else if ((checkAgainstTheme == false)
                && (directory.ExistsInGlobalDirectory == false))
            {
                // We are checking against the global directory, but the directory doesn't exist in the global directory
                return false;
            }

            // Check if there is a set value to reference
            // If there is no set value, no filters can be applied so the item must be included
            if (String.IsNullOrEmpty(currentSet) == true)
                return true;

            // Return whether the item is included
            return IncludeItem(directoryName, currentSet, checkAgainstTheme, true);
        }

        /// <summary>
        /// Checks if the item should be included.
        /// </summary>
        /// <param name="itemName">The name of the item.</param>
        /// <param name="currentSet">The name of the current filter set.</param>
        /// <param name="checkAgainstTheme"><see langword="true"/> if checking against the theme directory, otherwise <see langword="false"/> which will check against the global directory.</param>
        /// <param name="isDirectory"><see langword="true"/> if the item is a directory, otherwise <see langword="false"/>.</param>
        /// <returns><see langword="true"/> if the item is included, otherwise <see langword="false"/>.</returns>
        /// <remarks>None.</remarks>
        private Boolean IncludeItem(String itemName, String currentSet, Boolean checkAgainstTheme, Boolean isDirectory)
        {
            // NOTE: By the time this is called, the item does exist in either the files or directories dictionary collections

            // Check if there is a parent
            if (Parent != null)
            {
                // If the parent directory excludes this directory for the current set, then the child files and directories are also excluded
                if (Parent.DirectoryIsIncluded(Name, currentSet, checkAgainstTheme) == false)
                    return false;
            }

            VirtualPathFilter.FilterSet currentFilter = null;

            // Check if there is a filter set available
            if (checkAgainstTheme == true)
            {
                VirtualPathFilter.FilterDefinition themeFilter = ThemeFilterDefinition;

                if ((themeFilter != null)
                    && (themeFilter.FilterSets.ContainsKey(currentSet) == true))
                {
                    // We are checking against the theme directory and there is a filter definition for the directory and it contains a definition
                    // for the current filter set
                    currentFilter = themeFilter.FilterSets[currentSet];
                }
            }
            else if (checkAgainstTheme == false)
            {
                VirtualPathFilter.FilterDefinition globalFilter = GlobalFilterDefinition;

                if ((globalFilter != null)
                    && (globalFilter.FilterSets.ContainsKey(currentSet) == true))
                {
                    // We are checking against the global directory and there is a filter definition for the directory and it contains a definition
                    // for the current filter set
                    currentFilter = globalFilter.FilterSets[currentSet];
                }
            } 
        
            // If there is no filter set, the file will be included by default
            if (currentFilter == null)
                return true;

            VirtualPathFilter.FilterItemBase filterItem = null;

            // Attempt to get a reference to the theme filter item
            if ((isDirectory == false)
                && (currentFilter.Files.ContainsKey(itemName) == true))
            {
                // Get the filter item for the file
                filterItem = currentFilter.Files[itemName];
            }
            else if ((isDirectory == true)
                && (currentFilter.Directories.ContainsKey(itemName) == true))
            {
                // Get the filter item for the directory
                filterItem = currentFilter.Directories[itemName];
            }

            // Check if the item is defined in the theme set
            if (filterItem != null)
            {
                // The item is listed in the filter set

                // If the filter set is marked as excluding listed items, then the item will not be included
                // If the filter set is marked as not excluding listed items, then the item will be included

                return (currentFilter.ExcludeListedItems == false);
            }
            else
            {
                // The item is not listed in the filter set

                // If the filter set is marked as excluding listed items, then the item will be included
                // If the filter set is marked as not excluding listed items, then the item will not be included

                return currentFilter.ExcludeListedItems;
            }
        }

        /// <summary>
        /// Gets the file.
        /// </summary>
        /// <param name="fileName">Name of the file.</param>
        /// <returns>A <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemeFile"/> object.</returns>
        /// <remarks>None.</remarks>
        internal VirtualThemeFile GetFile(String fileName)
        {
            // Return the file from the dictionary
            return _files[fileName];
        }

        /// <summary>
        /// Gets the directory.
        /// </summary>
        /// <param name="virtualDir">The virtual dir.</param>
        /// <returns>A <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemeDirectory"/> object. Returns <see langword="null"/> if the directory can't be found.</returns>
        /// <remarks>None.</remarks>
        internal VirtualThemeDirectory GetDirectory(String virtualDir)
        {
            // Check if there are any directories to check against
            if (_directories.Count == 0)
                return null;

            // Ensure that the virtual path belongs to this directory
            if (virtualDir.StartsWith(VirtualPath, StringComparison.InvariantCultureIgnoreCase) == false)
                return null;

            // Get the virtual path relative to this directories virtual path
            String relativeVirtualPath = virtualDir.Substring(VirtualPath.Length);

            // Get the first directory name
            String directoryName = relativeVirtualPath.Substring(0, relativeVirtualPath.IndexOf("/"));

            // Get the child directory for the name discovered
            VirtualThemeDirectory childDirectory = _directories[directoryName];

            // Check if this child directory is the directory being searched for
            if (childDirectory.VirtualPath == virtualDir)
                return childDirectory;
            else
                return childDirectory.GetDirectory(virtualDir);
        }

        #endregion

        #region Properties
        
        /// <summary>
        /// Gets the parent <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemeDirectory"/>.
        /// </summary>
        /// <value>The parent <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemeDirectory"/>.</value>
        /// <remarks>
        /// This value will be <see langword="null"/> for the <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemeDirectory"/> that represents the base theme directory.
        /// All subdirectories that exist under the <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemeDirectory"/> 
        /// (in either the theme directory or the global directory) will have a parent reference assigned.
        /// </remarks>
        public VirtualThemeDirectory Parent
        {
            get
            {
                // Return the stored parent
                return _parent;
            }
        }

        /// <summary>
        /// Gets a value indicating whether the directory physically exists in either the theme or global paths.
        /// </summary>
        /// <value><see langword="true"/> if the directory exists; otherwise, <see langword="false"/>.</value>
        /// <remarks>None.</remarks>
        public Boolean Exists
        {
            get
            {
                // Return true if the theme or global directory exists
                return ((System.IO.Directory.Exists(_themeAbsolutePath) == true)
                    || (System.IO.Directory.Exists(_globalAbsolutePath) == true));
            }
        }

        /// <summary>
        /// Gets a value indicating whether the directory physically exists in the theme directory.
        /// </summary>
        /// <value><see langword="true"/> if the directory exists in the theme directory; otherwise, <see langword="false"/>.</value>
        /// <remarks>None.</remarks>
        private Boolean ExistsInThemeDirectory
        {
            get
            {
                // Return true if there is a theme absolute path
                // When the object is created, a path to the directory is supplied if that path exists
                return (String.IsNullOrEmpty(_themeAbsolutePath) == false);
            }
        }

        /// <summary>
        /// Gets a value indicating whether the directory physically exists in the global directory.
        /// </summary>
        /// <value><see langword="true"/> if the directory exists in the global directory; otherwise, <see langword="false"/>.</value>
        /// <remarks>None.</remarks>
        private Boolean ExistsInGlobalDirectory
        {
            get
            {
                // Return true if there is a global absolute path
                // When the object is created, a path to the directory is supplied if that path exists
                return (String.IsNullOrEmpty(_globalAbsolutePath) == false);
            }
        }

        /// <summary>
        /// Gets a list of all the subdirectories contained in this directory.
        /// </summary>
        /// <returns>
        /// An object implementing the <see cref="T:System.Collections.IEnumerable"></see> interface 
        /// containing <see cref="T:System.Web.Hosting.VirtualDirectory"></see> objects.
        /// </returns>
        /// <remarks>None.</remarks>
        public override System.Collections.IEnumerable Directories
        {
            get
            {
                return _directories.Values;
            }
        }

        /// <summary>
        /// Gets a list of all files contained in this directory.
        /// </summary>
        /// <returns>
        /// An object implementing the <see cref="T:System.Collections.IEnumerable"></see> interface 
        /// containing <see cref="T:System.Web.Hosting.VirtualFile"></see> objects.
        /// </returns>
        /// <remarks>None.</remarks>
        public override System.Collections.IEnumerable Files
        {
            get
            {
                return _files.Values;
            }
        }

        /// <summary>
        /// Gets a list of the files and subdirectories contained in this virtual directory.
        /// </summary>
        /// <returns>
        /// An object implementing the <see cref="T:System.Collections.IEnumerable"></see> interface 
        /// containing <see cref="T:System.Web.Hosting.VirtualFile"></see> and <see cref="T:System.Web.Hosting.VirtualDirectory"></see> objects.
        /// </returns>
        /// <remarks>None.</remarks>
        public override System.Collections.IEnumerable Children
        {
            get
            {
                return _children.Values;
            }
        }

        /// <summary>
        /// Gets the <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDefinition"/> for the <c>VirtualThemePathFilters.config</c> file found in the theme directory.
        /// </summary>
        /// <value>The filter definition for the theme directory.</value>
        /// <remarks>
        /// <para>Returns <see langword="null"/> if the <c>VirtualThemePathFilters.config</c> file is not found in the theme directory.</para>
        /// <para>The <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDefinition"/> is stored in <see cref="T:System.Web.Caching.Cache"/> 
        /// with a dependency on the file path of the definition file. If the contents of the definition file is modified, this property will be reloaded to reflect the changes.
        /// The application does not need to be restarted for these changes to be reloaded.</para>
        /// </remarks>
        private VirtualPathFilter.FilterDefinition ThemeFilterDefinition
        {
            get
            {
                // Check if there is a theme filter path
                if (String.IsNullOrEmpty(_themeFilterDefinitionAbsolutePath) == true)
                    return null;

                // Attempt to get the theme filter from the cache
                VirtualPathFilter.FilterDefinition themeFilter 
                    = System.Web.Hosting.HostingEnvironment.Cache[VirtualThemePathProvider.CacheKeyPrefix + _themeFilterDefinitionAbsolutePath] as VirtualPathFilter.FilterDefinition;

                // Return the stored object if it was found in the cache
                if (themeFilter != null)
                    return themeFilter;

                // The item wasn't found in the cache
                themeFilter = new Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDefinition(_themeFilterDefinitionAbsolutePath);

                // Store the item in the cache with a dependency on the file it is loaded from
                System.Web.Hosting.HostingEnvironment.Cache.Insert(
                    VirtualThemePathProvider.CacheKeyPrefix + _themeFilterDefinitionAbsolutePath, 
                    themeFilter, 
                    new System.Web.Caching.CacheDependency(_themeFilterDefinitionAbsolutePath));

                // Return the created filter
                return themeFilter;
            }
        }

        /// <summary>
        /// Gets the <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDefinition"/> for the <c>VirtualThemePathFilters.config</c> file found in the global directory.
        /// </summary>
        /// <value>The filter definition for the global directory.</value>
        /// <remarks>
        /// <para>Returns <see langword="null"/> if the <c>VirtualThemePathFilters.config</c> file is not found in the global directory.</para>
        /// <para>The <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDefinition"/> is stored in <see cref="T:System.Web.Caching.Cache"/> 
        /// with a dependency on the file path of the definition file. If the contents of the definition file is modified, this property will be reloaded to reflect the changes.
        /// The application does not need to be restarted for these changes to be reloaded.</para>
        /// </remarks>
        private VirtualPathFilter.FilterDefinition GlobalFilterDefinition
        {
            get
            {
                // Check if there is a global filter path
                if (String.IsNullOrEmpty(_globalFilterDefinitionAbsolutePath) == true)
                    return null;

                // Attempt to get the global filter from the cache
                VirtualPathFilter.FilterDefinition globalFilter 
                    = System.Web.Hosting.HostingEnvironment.Cache[VirtualThemePathProvider.CacheKeyPrefix + _globalFilterDefinitionAbsolutePath] as VirtualPathFilter.FilterDefinition;

                // Return the stored object if it was found in the cache
                if (globalFilter != null)
                    return globalFilter;

                // The item wasn't found in the cache
                globalFilter = new Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDefinition(_globalFilterDefinitionAbsolutePath);

                // Store the item in the cache with a dependency on the file it is loaded from
                System.Web.Hosting.HostingEnvironment.Cache.Insert(
                    VirtualThemePathProvider.CacheKeyPrefix + _globalFilterDefinitionAbsolutePath, 
                    globalFilter, 
                    new System.Web.Caching.CacheDependency(_globalFilterDefinitionAbsolutePath));

                // Return the created filter
                return globalFilter;
            }
        }

        /// <summary>
        /// Gets the absolute path to the theme directory.
        /// </summary>
        /// <value>The absolute path to the theme directory.</value>
        /// <remarks>None.</remarks>
        private String ThemeAbsolutePath
        {
            get
            {
                return _themeAbsolutePath;
            }
        }

        /// <summary>
        /// Gets the absolute path to the global directory.
        /// </summary>
        /// <value>The absolute path to the global directory.</value>
        /// <remarks>None.</remarks>
        private String GlobalAbsolutePath
        {
            get
            {
                return _globalAbsolutePath;
            }
        }

        #endregion
    }
}
