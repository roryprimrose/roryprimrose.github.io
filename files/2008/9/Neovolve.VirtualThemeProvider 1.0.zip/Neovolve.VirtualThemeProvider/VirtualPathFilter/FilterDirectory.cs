using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace Neovolve.VirtualThemeProvider.VirtualPathFilter
{
    /// <summary>
    /// The <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDirectory"/> class identifies a directory name that has been identified in a <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterSet"/> 
    /// belonging to a <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDefinition"/>.
    /// </summary>
    /// <remarks>None.</remarks>
    internal class FilterDirectory : FilterItemBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDirectory"/> class.
        /// </summary>
        /// <param name="parentDirectoryPath">The parent directory path.</param>
        /// <param name="node">The node.</param>
        /// <remarks>None.</remarks>
        public FilterDirectory(String parentDirectoryPath, XmlNode node)
            : base(parentDirectoryPath, node)
        {
        }
    }
}
