using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace Neovolve.VirtualThemeProvider.VirtualPathFilter
{
    /// <summary>
    /// The <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterFile"/> class identifies a file name that has been identified in a <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterSet"/> 
    /// belonging to a <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDefinition"/>.
    /// </summary>
    /// <remarks>None.</remarks>
    internal class FilterFile : FilterItemBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterFile"/> class.
        /// </summary>
        /// <param name="parentDirectoryPath">The parent directory path.</param>
        /// <param name="node">The node.</param>
        /// <remarks>None.</remarks>
        public FilterFile(String parentDirectoryPath, XmlNode node)
            : base(parentDirectoryPath, node)
        {
        }
    }
}
