using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace Neovolve.VirtualThemeProvider.VirtualPathFilter
{
    /// <summary>
    /// The <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterItemBase"/> class is an abstract class that contains the data definition that is used by <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterFile"/> 
    /// and <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDirectory"/> classes.
    /// </summary>
    /// <remarks>None.</remarks>
    internal abstract class FilterItemBase
    {
        #region Declarations

        /// <summary>
        /// Defines the name of the attribute to populate the Name property from.
        /// </summary>
        /// <remarks>None.</remarks>
        private const String NameKey = "name";        

        /// <summary>
        /// Stores the name of the item.
        /// </summary>
        /// <remarks>None.</remarks>
        private String _name = String.Empty;

        /// <summary>
        /// Stores the path of the item.
        /// </summary>
        /// <remarks>None.</remarks>
        private String _path = String.Empty;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterItemBase"/> class.
        /// </summary>
        /// <param name="parentDirectoryPath">The parent directory path.</param>
        /// <param name="node">The node.</param>
        /// <remarks>None.</remarks>
        public FilterItemBase(String parentDirectoryPath, XmlNode node)
        {
            // Store the name and path of the item
            _name = node.Attributes[NameKey].Value;
            _path = System.IO.Path.Combine(parentDirectoryPath, _name);
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets the name of the item.
        /// </summary>
        /// <value>The name of the item.</value>
        /// <remarks>None.</remarks>
        public String Name
        {
            get
            {
                return _name;
            }
        }

        /// <summary>
        /// Gets the path of the item.
        /// </summary>
        /// <value>The path of the item.</value>
        /// <remarks>None.</remarks>
        public String Path
        {
            get
            {
                return _path;
            }
        }

        #endregion
    }
}
