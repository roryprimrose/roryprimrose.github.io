using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace Neovolve.VirtualThemeProvider.VirtualPathFilter
{
    /// <summary>
    /// The <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDefinition"/> class holds filter definition information for the files and subdirectories in a directory. 
    /// The <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDefinition"/> is populated from an xml file with
    /// the name <c>VirtualThemePathFilters.config</c>. These filter definition files
    /// may exist in any physical directory in or under the global and theme directories.
    /// </summary>
    /// <remarks>
    /// 
    /// <para>When the xml data is loaded by a <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDefinition"/> it will contains a 
    /// collection of <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterSet"/> objects. 
    /// Each <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterSet"/> is identified by a <see cref="P:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterSet.Name"/>.
    /// </para>
    /// 
    /// <para>
    /// When a theme is processed, the contents of each physical directory will be compared to the 
    /// <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDefinition"/> if one exists in that directory. 
    /// The <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterSet"/> that has the name of the 
    /// <see cref="P:Neovolve.VirtualThemeProvider.VirtualThemePathProvider.CurrentSet">VirtualThemePathProvider.CurrentSet</see> value will be used to apply the filter rules.
    /// </para>
    /// 
    /// <para>
    /// If there is no <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDefinition"/> in the directory,
    /// or no <see cref="P:Neovolve.VirtualThemeProvider.VirtualThemePathProvider.CurrentSet" /> value is assigned, 
    /// or the <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterSet"/> doesn't exist in the 
    /// <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDefinition"/>, 
    /// then all the subdirectories and files in the directory will be included by default.
    /// </para>
    /// 
    /// <para>
    /// If there is a <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterSet"/> identified for the directory, then the rules defined in the 
    /// <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterSet"/> will be applied to each item in that directory.</para>
    /// 
    /// <para>For information on how filter rules are applied, refer to the Remarks section for the <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterSet"/> class.</para>
    /// 
    /// <para><b>Note:</b> FilterDefinition files will only apply filter rules to directories and files in the same directory that the 
    /// <c>VirtualThemePathFilters.config</c> file is located in.
    /// If an item in the global directory needs to be filtered as well as an item in the theme directory, then a 
    /// <c>VirtualThemePathFilters.config</c> file will need to be
    /// created in each directory.</para>
    /// 
    /// <para>The following is an example of a FilterDefinition file:
    /// <example>
    /// <code>
    /// &lt;filterSets&gt;
    ///     &lt;filterSet name=&quot;Set1&quot; excludeListedItems=&quot;false&quot;&gt;
    ///         &lt;file name=&quot;A.css&quot; /&gt;
    ///     &lt;/filterSet&gt;
    ///     &lt;filterSet name=&quot;Set2&quot; excludeListedItems=&quot;false&quot;&gt;
    ///         &lt;file name=&quot;B.css&quot; /&gt;
    ///         &lt;directory name=&quot;SubFolder&quot; /&gt;
    ///     &lt;/filterSet&gt;
    ///     &lt;filterSet name=&quot;Set3&quot; excludeListedItems=&quot;true&quot;&gt;
    ///         &lt;file name=&quot;C.css&quot; /&gt;
    ///         &lt;directory name=&quot;SubFolder&quot; /&gt;
    ///     &lt;/filterSet&gt;
    /// &lt;/filterSets&gt;
    /// </code>
    /// </example>
    /// </para>
    /// 
    /// <para>
    /// The following table outlines how the above example FilterDefinition file would be applied to a theme directory which contains the files A.css, B.css, C.css, D.css 
    /// and the directory SubFolder.
    /// <list type="table">
    /// <listheader>
    ///     <th width="34%">CurrentSet</th>
    ///     <th width="33%">Items included</th>
    ///     <th width="33%">Items excluded</th>
    /// </listheader>
    /// <item>
    /// <description><see cref="F:System.String.Empty">String.Empty</see></description>
    /// <description>
    /// A.css<br />
    /// B.css<br />
    /// C.css<br />
    /// D.css<br />
    /// SubFolder
    /// </description>
    /// <description></description>
    /// </item>
    /// <item>
    /// <description>Set1</description>
    /// <description>
    /// A.css
    /// </description>
    /// <description>
    /// B.css<br />
    /// C.css<br />
    /// D.css<br />
    /// SubFolder
    /// </description>
    /// </item>
    /// <item>
    /// <description>Set2</description>
    /// <description>
    /// B.css<br />
    /// SubFolder
    /// </description>
    /// <description>
    /// A.css<br />
    /// C.css<br />
    /// D.css
    /// </description>
    /// </item>
    /// <item>
    /// <description>Set3</description>
    /// <description>
    /// A.css<br />
    /// B.css<br />
    /// D.css
    /// </description>
    /// <description>
    /// C.css<br />
    /// SubFolder
    /// </description>
    /// </item>
    /// <item>
    /// <description>XYZ</description>
    /// <description>
    /// A.css<br />
    /// B.css<br />
    /// D.css<br />
    /// C.css<br />
    /// SubFolder
    /// </description>
    /// <description>
    /// </description>
    /// </item>
    /// </list>
    /// </para>
    /// 
    /// </remarks>
    internal class FilterDefinition
    {
        #region Declarations

        /// <summary>
        /// Stores whether the Xml loaded from the filter definition file is valid.
        /// </summary>
        /// <remarks>None.</remarks>
        private Boolean _xmlIsValid = true;

        /// <summary>
        /// Stores the list of errors encountered while validating the filter definition data against the schema.
        /// </summary>
        /// <remarks>None.</remarks>
        private String _schemaErrors = String.Empty;

        /// <summary>
        /// Stores the list of filter sets found in the filter definition file.
        /// </summary>
        /// <remarks>None.</remarks>
        private Dictionary<String, FilterSet> _filterSets = null;

        /// <summary>
        /// Defines the Xpath query to use for selecting the filter sets in the filter definition data.
        /// </summary>
        /// <remarks>None.</remarks>
        private const String FilterSetsXPathQuery = "//filterSets/filterSet";
        
        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDefinition"/> class.
        /// </summary>
        /// <param name="filePath">The file path.</param>
        /// <remarks>None.</remarks>
        public FilterDefinition(String filePath)
        {
            // Load the filter information
            LoadFilters(filePath);
        }

        #endregion

        #region Methods

        /// <summary>
        /// Loads the filters.
        /// </summary>
        /// <param name="filePath">The file path.</param>
        /// <remarks>None.</remarks>
        /// <exception cref="T:System.ArgumentException">Thrown when the file path specified does not exist.</exception>
        private void LoadFilters(String filePath)
        {
            if (System.IO.File.Exists(filePath) == false)
                throw new System.ArgumentException("File does not exist.", "filePath");

            // Validate the data in the file
            ValidateXML(filePath);

            // Create the xml document
            XmlDocument document = new XmlDocument();

            // Load the filter definition data
            document.Load(filePath);

            // Get the collection of filter sets
            XmlNodeList nodes = document.SelectNodes(FilterSetsXPathQuery);

            // Create the collection
            _filterSets = new Dictionary<String, FilterSet>();

            // Store the directory path
            String directoryPath = System.IO.Path.GetDirectoryName(filePath);

            // Loop through each filter found
            foreach (XmlNode node in nodes)
            {
                // Create the filter set
                FilterSet set = new FilterSet(directoryPath, node);

                // Add the filter set to the dictionary using the name as the key
                _filterSets.Add(set.Name, set);
            }
        }

        /// <summary>
        /// Validates the XML.
        /// </summary>
        /// <param name="filePath">The file path.</param>
        /// <remarks>None.</remarks>
        /// <exception cref="T:Neovolve.VirtualThemeProvider.Exceptions.SchemaValidationFailedException">
        /// Thrown when the filter definition file fails schema validation.
        /// </exception>
        private void ValidateXML(String filePath)
        {
            System.IO.Stream resourceStream = null;
            System.IO.StreamReader reader = null;
            XmlReaderSettings schemaValidator = null;
            XmlReader schemaReader = null;
            XmlReader validatorReader = null;

            try
            {
                // Load the schema from the resource
                resourceStream = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream(this.GetType().Namespace + ".FilterSetsSchema.xsd");
                reader = new System.IO.StreamReader(resourceStream);

                // Create the validator
                schemaValidator = new XmlReaderSettings();
                schemaValidator.ValidationType = ValidationType.Schema;
                schemaValidator.Schemas.Add(System.Xml.Schema.XmlSchema.Read(new XmlTextReader(reader), null));
                schemaValidator.ValidationEventHandler += new System.Xml.Schema.ValidationEventHandler(schemaValidator_ValidationEventHandler);

                // Read the xml data
                schemaReader = XmlReader.Create(new System.IO.StringReader(System.IO.File.ReadAllText(filePath)));
                validatorReader = XmlReader.Create(schemaReader, schemaValidator);

                // Validate the xml document
                while (validatorReader.Read()) { }

                // If the xml data is invalid, throw an exception
                if (_xmlIsValid == false)
                    throw new Exceptions.SchemaValidationFailedException(filePath, _schemaErrors);
            }
            finally
            {
                // Clean up the object references
                if (resourceStream != null)
                {
                    resourceStream.Close();
                    resourceStream.Dispose();
                    resourceStream = null;
                }

                if (reader != null)
                {
                    reader.Close();
                    reader.Dispose();
                    reader = null;
                }

                if (schemaReader != null)
                    schemaReader.Close();

                if (validatorReader != null)
                    validatorReader.Close();
            }
        }

        /// <summary>
        /// Handles the ValidationEventHandler event of the schema validator.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="T:System.Xml.Schema.ValidationEventArgs"/> instance containing the event data.</param>
        /// <remarks>None.</remarks>
        private void schemaValidator_ValidationEventHandler(object sender, System.Xml.Schema.ValidationEventArgs e)
        {
            // Mark the xml as invalid and store the message
            _xmlIsValid = false;
            _schemaErrors += e.Message + System.Environment.NewLine;
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets the filter sets.
        /// </summary>
        /// <value>The filter sets.</value>
        /// <remarks>None.</remarks>
        public Dictionary<String, FilterSet> FilterSets
        {
            get
            {
                return _filterSets;
            }
        }

        #endregion
    }
}
