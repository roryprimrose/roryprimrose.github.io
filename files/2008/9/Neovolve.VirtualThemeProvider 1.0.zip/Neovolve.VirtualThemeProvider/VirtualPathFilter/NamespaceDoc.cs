using System;
using System.Collections.Generic;
using System.Text;

namespace Neovolve.VirtualThemeProvider.VirtualPathFilter
{
#if DEBUG
    /// <summary>
    /// The Neovolve.VirtualThemeProvider.VirtualPathFilter namespace provides functionality for loading filter set definitions.
    /// </summary>
    /// <remarks>None.</remarks>
    public class NamespaceDoc
    {
    }
#endif
}
