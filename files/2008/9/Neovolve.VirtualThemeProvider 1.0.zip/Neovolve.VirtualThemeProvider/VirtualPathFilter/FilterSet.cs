using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace Neovolve.VirtualThemeProvider.VirtualPathFilter
{
    /// <summary>
    /// The <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterSet"/> class contains a list of <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterFile"/> 
    /// and <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDirectory"/> instances loaded by 
    /// a <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDefinition"/>.
    /// It defines the rules by which the <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemePathProvider"/> determines which files and subdirectories are included in a physical
    /// theme directory for the current request.
    /// </summary>
    /// <remarks>
    /// 
    /// <para>Each <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterDirectory"/> and <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterFile"/>
    /// defined in a <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterSet"/> will be identified by name. 
    /// The <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterSet"/>, by means of the 
    /// <see cref="P:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterSet.ExcludeListedItems"/> value, indicates whether the items
    /// listed in the set are included or excluded from the <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemeDirectory"/>. 
    /// This value is compared against the list of directories and files in the set to determine whether the item is to be included in the theme.</para>
    /// 
    /// <para>The possible outcomes of this comparison are:
    /// <list type="bullet">
    /// <item><description>When <see cref="P:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterSet.ExcludeListedItems"/> is <see langword="false"/> 
    /// and the item is listed in the set, the item is included.</description></item>
    /// <item><description>When <see cref="P:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterSet.ExcludeListedItems"/> is <see langword="false"/> 
    /// and the item is not listed in the set, the item is excluded.</description></item>
    /// <item><description>When <see cref="P:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterSet.ExcludeListedItems"/> is <see langword="true"/> 
    /// and the item is listed in the set, the item is excluded.</description></item>
    /// <item><description>When <see cref="P:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterSet.ExcludeListedItems"/> is <see langword="true"/> 
    /// and the item is not listed in the set, the item is included.</description></item>
    /// </list>
    /// </para>
    /// 
    /// <para>An efficient way to manage theme files and their required filters is to group theme files into subdirectories in the theme or global directory. 
    /// The <c>VirtualThemePathFilters.config</c> file of the parent directory can be used to determine which subdirectory is included or excluded as required. 
    /// This avoids having to list a potentially large number of files across the filter sets in the <c>VirtualThemePathFilters.config</c> file.</para>
    /// 
    /// <para><b>Note:</b> Skin files cannot be filtered as ASP.Net only requests whether the file exists once rather than on each request to a theme directory.</para>
    /// 
    /// </remarks>
    internal class FilterSet
    {
        #region Declarations

        /// <summary>
        /// Defines the name of the attribute to load the Name property from.
        /// </summary>
        /// <remarks>None.</remarks>
        private const String NameKey = "name";

        /// <summary>
        /// Defines the name of the attribute to load the ExcludeListedItems property from.
        /// </summary>
        /// <remarks>None.</remarks>
        private const String ExcludeListedItemsKey = "excludeListedItems";

        /// <summary>
        /// Defines the Xpath query to find the files.
        /// </summary>
        /// <remarks>None.</remarks>
        private const String FileXPath = "file";

        /// <summary>
        /// Defines the Xpath query to find the directories.
        /// </summary>
        /// <remarks>None.</remarks>
        private const String DirectoryXPath = "directory";

        /// <summary>
        /// Stores the name of the filter set.
        /// </summary>
        /// <remarks>None.</remarks>
        private String _name = String.Empty;

        /// <summary>
        /// Stores whether listed items should be included or excluded.
        /// </summary>
        /// <remarks>None.</remarks>
        private Boolean _excludeListedItems = true;

        /// <summary>
        /// Stores the list of files defined in the filter set.
        /// </summary>
        /// <remarks>None.</remarks>
        private Dictionary<String, FilterFile> _files = null;

        /// <summary>
        /// Stores the list of directories defined in the filter set.
        /// </summary>
        /// <remarks>None.</remarks>
        private Dictionary<String, FilterDirectory> _directories = null;
        
        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="T:Neovolve.VirtualThemeProvider.VirtualPathFilter.FilterSet"/> class.
        /// </summary>
        /// <param name="directoryPath">The directory path.</param>
        /// <param name="node">The node.</param>
        /// <remarks>None.</remarks>
        /// <exception cref="T:Neovolve.VirtualThemeProvider.Exceptions.InvalidFilterFileDefinitionException">
        /// Thrown when a filter file is specified without a file extension or where a skin file is defined.
        /// </exception>
        public FilterSet(String directoryPath, XmlNode node)
        {
            // Get the name and exclude by default setting
            _name = node.Attributes[NameKey].Value;
            _excludeListedItems = System.Boolean.Parse(node.Attributes[ExcludeListedItemsKey].Value);

            // Load the files defined
            _files = new Dictionary<String, FilterFile>();
            XmlNodeList fileNodes = node.SelectNodes(FileXPath);

            // Loop through each file defined
            foreach (XmlNode fileNode in fileNodes)
            {
                // Create a new filter file from the node
                FilterFile fileFilter = new FilterFile(directoryPath, fileNode);

                // Get the extension of the file specified
                String fileExtension = System.IO.Path.GetExtension(fileFilter.Name);

                if (String.IsNullOrEmpty(fileExtension) == true)
                {
                    // Throw an exception if there is no extension
                    throw new Exceptions.InvalidFilterFileDefinitionException(
                        fileFilter.Name, 
                        _name, 
                        System.IO.Path.Combine(directoryPath, VirtualThemePathProvider.FilterDefinitionFileName),
                        "No file extension specified for the file.");
                }
                else if (fileExtension.ToUpper() == ".SKIN")
                {
                    // Throw an exception if the filter file is a skin file
                    throw new Exceptions.InvalidFilterFileDefinitionException(
                        fileFilter.Name, 
                        _name,
                        System.IO.Path.Combine(directoryPath, VirtualThemePathProvider.FilterDefinitionFileName),
                        "Skin files cannot be filtered.");
                }

                // Add the filter file to the files collection
                _files.Add(fileFilter.Name, fileFilter);
            }

            // Load the directories defined
            _directories = new Dictionary<String, FilterDirectory>();
            XmlNodeList directoryNodes = node.SelectNodes(DirectoryXPath);

            // Loop through each directory defined
            foreach (XmlNode directoryNode in directoryNodes)
            {
                // Create a new filter directory from the node
                FilterDirectory directoryFilter = new FilterDirectory(directoryPath, directoryNode);

                // Add the filter directory to the directories collection
                _directories.Add(directoryFilter.Name, directoryFilter);
            }
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets the name.
        /// </summary>
        /// <value>The name.</value>
        /// <remarks>None.</remarks>
        public String Name
        {
            get
            {
                return _name;
            }
        }

        /// <summary>
        /// Gets a value indicating whether listed items are to be excluded or included.
        /// </summary>
        /// <value><see langword="true"/> if listed items are to excluded; otherwise, <see langword="false"/>.</value>
        /// <remarks>
        /// The inverse value is applied to unlisted files. 
        /// If listed files are excluded, then unlisted files are included.
        /// If listed files are included, then unlisted files are excluded.
        /// </remarks>
        public Boolean ExcludeListedItems
        {
            get
            {
                return _excludeListedItems;
            }
        }

        /// <summary>
        /// Gets the files.
        /// </summary>
        /// <value>The files.</value>
        /// <remarks>None.</remarks>
        public Dictionary<String, FilterFile> Files
        {
            get
            {
                return _files;
            }
        }

        /// <summary>
        /// Gets the directories.
        /// </summary>
        /// <value>The directories.</value>
        /// <remarks>None.</remarks>
        public Dictionary<String, FilterDirectory> Directories
        {
            get
            {
                return _directories;
            }
        }

        #endregion
    }
}
