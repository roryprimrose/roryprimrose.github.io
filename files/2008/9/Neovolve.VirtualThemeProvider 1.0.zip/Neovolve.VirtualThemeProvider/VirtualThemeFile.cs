using System;
using System.Collections.Generic;
using System.Text;
using System.Web;

namespace Neovolve.VirtualThemeProvider
{
    /// <summary>
    /// The <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemeFile"/> class contains information about a virtual file. 
    /// </summary>
    /// <remarks>None.</remarks>
    public class VirtualThemeFile : System.Web.Hosting.VirtualFile
    {
        #region Declarations

        /// <summary>
        /// Stores the absolute path to the file in the theme directory.
        /// </summary>
        /// <remarks>This value will be <see cref="F:System.String.Empty">String.Empty</see> if the file does not exist in the theme directory.</remarks>
        private String _themeAbsolutePath = String.Empty;

        /// <summary>
        /// Stores the absolute path to the file in the global theme directory.
        /// </summary>
        /// <remarks>This value will be <see cref="F:System.String.Empty">String.Empty</see> if the file does not exist in the global theme directory.</remarks>
        private String _globalAbsolutePath = String.Empty;

        /// <summary>
        /// Stores the parent <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemeDirectory"/>.
        /// </summary>
        /// <remarks>None.</remarks>
        private VirtualThemeDirectory _parent = null;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemeFile"/> class.
        /// </summary>
        /// <param name="virtualPath">The virtual path.</param>
        /// <param name="themeAbsolutePath">The theme absolute path.</param>
        /// <param name="globalAbsolutePath">The global absolute path.</param>
        /// <param name="parent">The parent.</param>
        /// <remarks>None.</remarks>
        public VirtualThemeFile(String virtualPath,
            String themeAbsolutePath, 
            String globalAbsolutePath,
            VirtualThemeDirectory parent)
            : base(virtualPath)
        {
            _themeAbsolutePath = themeAbsolutePath;
            _globalAbsolutePath = globalAbsolutePath;
            _parent = parent;
        }

        #endregion

        #region Functions

        /// <summary>
        /// Returns a read-only stream to the virtual resource.
        /// </summary>
        /// <returns>A read-only stream to the virtual file.</returns>
        /// <remarks>None.</remarks>
        public override System.IO.Stream Open()
        {
            return System.IO.File.Open(AbsolutePath, System.IO.FileMode.Open);
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets the parent <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemeDirectory"/>.
        /// </summary>
        /// <value>The parent <see cref="T:Neovolve.VirtualThemeProvider.VirtualThemeDirectory"/>.</value>
        /// <remarks>None.</remarks>
        public VirtualThemeDirectory Parent
        {
            get
            {
                return _parent;
            }
        }

        /// <summary>
        /// Gets the absolute path.
        /// </summary>
        /// <value>The absolute path.</value>
        /// <remarks>None.</remarks>
        private String AbsolutePath
        {
            get
            {
                // Get the current set value
                String currentSet = VirtualThemePathProvider.Current.CurrentSet;

                if ((String.IsNullOrEmpty(_themeAbsolutePath) == false)
                    && (Parent.FileIsIncluded(Name, currentSet, true) == true))
                    return _themeAbsolutePath;
                else if ((String.IsNullOrEmpty(_globalAbsolutePath) == false)
                    && (Parent.FileIsIncluded(Name, currentSet, false) == true))
                    return _globalAbsolutePath;

                return String.Empty;
            }
        }

        /// <summary>
        /// Gets a value indicating whether the file exists in the theme directory.
        /// </summary>
        /// <value><see langword="true"/> if the file exists in the theme directory; otherwise, <see langword="false"/>.</value>
        /// <remarks>None.</remarks>
        internal Boolean ExistsInThemeDirectory
        {
            get
            {
                // Return true if there is a theme absolute path
                // When the object is created, a path to the file is supplied if that path exists
                return (String.IsNullOrEmpty(_themeAbsolutePath) == false);
            }
        }

        /// <summary>
        /// Gets a value indicating whether the file exists in the global directory.
        /// </summary>
        /// <value><see langword="true"/> if the file exists in the global directory; otherwise, <see langword="false"/>.</value>
        /// <remarks>None.</remarks>
        internal Boolean ExistsInGlobalDirectory
        {
            get
            {
                // Return true if there is a global absolute path
                // When the object is created, a path to the file is supplied if that path exists
                return (String.IsNullOrEmpty(_globalAbsolutePath) == false);
            }
        }

        #endregion
    }
}
