using System;
using System.Collections.Generic;
using System.Text;

using System.ServiceModel;
using System.ServiceModel.Description;
using System.Diagnostics;
using System.Management.Instrumentation;

using TechEd.Demo.Contracts;

namespace TechEd.Demo.Service
{
    [
        ServiceBehavior(InstanceContextMode=InstanceContextMode.Single)
    ]
    public class DemoService : IDemoService
    {
        public DemoService()
        {
            CreateWmiProvider();
        }

        #region IDemoService Members

        public DateTime GetServerDate()
        {
            return System.DateTime.Now;
        }

        public DateTime GetPreviousBusinessDate(DateTime referenceValue)
        {
            WmiProvider.IncrementTotalPreviousBusinessDayCalls();

            SourceProvider.TraceEvent(TraceEventType.Warning, 876, "Previous business date calculated.");

            CounterProvider.IncrementTotalPreviousBusinessDayCalls();

            switch (referenceValue.DayOfWeek)
            {
                case DayOfWeek.Saturday:

                    return referenceValue.AddDays(-1);

                case DayOfWeek.Sunday:

                    return referenceValue.AddDays(-2);

                case DayOfWeek.Monday:

                    return referenceValue.AddDays(-3);

                default:

                    return referenceValue;
            }
        }

        public DateTime GetNextBusinessDate(DateTime referenceValue)
        {
            WmiProvider.IncrementTotalNextBusinessDayCalls();

            SourceProvider.TraceEvent(TraceEventType.Warning, 654, "Next business date calculated.");

            CounterProvider.IncrementTotalNextBusinessDayCalls();

            switch (referenceValue.DayOfWeek)
            {
                case DayOfWeek.Friday:

                    return referenceValue.AddDays(3);

                case DayOfWeek.Saturday:

                    return referenceValue.AddDays(2);

                case DayOfWeek.Sunday:

                    return referenceValue.AddDays(1);

                default:

                    return referenceValue;
            }
        }

        #endregion

        #region Wmi Provider

        private DemoServiceWmiProvider _serviceWmiProvider = null;

        private void CreateWmiProvider()
        {
            Instrumentation.Publish(WmiProvider);
        }

        private DemoServiceWmiProvider WmiProvider
        {
            get
            {
                if (_serviceWmiProvider != null)
                    return _serviceWmiProvider;

                _serviceWmiProvider = new DemoServiceWmiProvider();

                return _serviceWmiProvider;
            }
        }
        
        #endregion

        #region Trace Provider

        private TraceSource _sourceProvider = null;

        private TraceSource SourceProvider
        {
            get
            {
                if (_sourceProvider != null)
                    return _sourceProvider;

                _sourceProvider = new TraceSource("System.ServiceModel.MessageLogging");

                return _sourceProvider;
            }
        }

        #endregion

        #region Performance Provider

        private DemoServiceCounterProvider _counterProvider = null;

        public void CreatePerformanceCountersForEndPoint(ServiceEndpoint endPoint)
        {
            CounterProvider.CreatePerformanceCounters(this.GetType(), endPoint);
        }

        private DemoServiceCounterProvider CounterProvider
        {
            get
            {
                if (_counterProvider != null)
                    return _counterProvider;

                _counterProvider = new DemoServiceCounterProvider();

                return _counterProvider;
            }
        }
        
        #endregion
    }
}
