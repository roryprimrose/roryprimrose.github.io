using System;
using System.Collections.Generic;
using System.Text;

using System.Configuration;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Configuration;

using TechEd.Demo.Service;

namespace TechEd.Demo.Host
{
    class Program
    {
        static void Main(string[] args)
        {
            Type serviceType = typeof(DemoService);

            // Load the service config
            ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
            fileMap.ExeConfigFilename = AppDomain.CurrentDomain.SetupInformation.ConfigurationFile;
            Configuration appConfig = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
            ServiceModelSectionGroup serviceModel = ServiceModelSectionGroup.GetSectionGroup(appConfig);
            ServiceElement serviceConfig = serviceModel.Services.Services[serviceType.FullName];
            ServiceEndpointElement serviceEndPointConfig = serviceConfig.Endpoints[0];

            Console.WriteLine("Creating performance counter category");
            DemoServiceCounterProvider.CreateCounterCategory();

            Console.WriteLine("Creating service");
            DemoService serviceInstance = new DemoService();

            Console.WriteLine("Creating service host");
            using (ServiceHost host
                = new ServiceHost(serviceInstance,
                    new Uri[] { serviceEndPointConfig.Address }))
            {
                Console.WriteLine("Creating performance counters");
                ServiceEndpoint endPoint = host.Description.Endpoints.Find(serviceEndPointConfig.Address);
                serviceInstance.CreatePerformanceCountersForEndPoint(endPoint);
                
                Console.WriteLine("Opening the service host");
                host.Open();

                Console.WriteLine("The service is available");
                Console.ReadKey();
            }

            Console.WriteLine("Destroying performance counter category");
            DemoServiceCounterProvider.DestroyCounterCategory();
        }
    }
}
