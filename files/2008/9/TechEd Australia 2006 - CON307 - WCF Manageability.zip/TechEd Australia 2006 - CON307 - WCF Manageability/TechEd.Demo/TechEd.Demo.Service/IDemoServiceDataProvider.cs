using System;
using System.Collections.Generic;
using System.Text;

namespace TechEd.Demo.Service
{
    public interface IDemoServiceDataProvider
    {
        void IncrementTotalPreviousBusinessDayCalls();

        long TotalPreviousBusinessDayCalls
        {
            get;
        }

        void IncrementTotalNextBusinessDayCalls();

        long TotalNextBusinessDayCalls
        {
            get;
        }
    }
}
