using System;
using System.Collections.Generic;
using System.Text;

using System.ServiceModel.Description;
using System.Diagnostics;

namespace TechEd.Demo.Service
{
    public class DemoServiceCounterProvider : IDemoServiceDataProvider
    {
        private const String CounterCategoryName = "TechEd Demo";

        private const String PreviousCounterName = "Previous Business Day";
        private PerformanceCounter _previousBusinessDayCounter = null;

        private const String NextCounterName = "Next Business Day";
        private PerformanceCounter _nextBusinessDayCounter = null;

        public static void CreateCounterCategory()
        {
            // Destroy the category if it already exists
            if (PerformanceCounterCategory.Exists(CounterCategoryName) == true)
                PerformanceCounterCategory.Delete(CounterCategoryName);

            CounterCreationData previousBusinessDayCounterData
                = new CounterCreationData(
                    PreviousCounterName,
                    "Number of times a previous business day is calculated",
                    PerformanceCounterType.NumberOfItems32);

            CounterCreationData nextBusinessDayCounterData
                = new CounterCreationData(
                    NextCounterName,
                    "Number of times the next business day is calculated.",
                    PerformanceCounterType.NumberOfItems32);

            CounterCreationDataCollection counters
                = new CounterCreationDataCollection(
                    new CounterCreationData[] { previousBusinessDayCounterData, nextBusinessDayCounterData });

            PerformanceCounterCategory.Create(
                CounterCategoryName,
                "TechEd demo counters",
                PerformanceCounterCategoryType.MultiInstance,
                counters);
        }

        public static void DestroyCounterCategory()
        {
            if (PerformanceCounterCategory.Exists(CounterCategoryName) == true)
                PerformanceCounterCategory.Delete(CounterCategoryName);
        }

        public void CreatePerformanceCounters(Type serviceType, ServiceEndpoint endPoint)
        {
            String name = String.Format("{0}@{1}", serviceType.Name, endPoint.Address.ToString());
            String instanceName = name.Replace("/", "|");

            _previousBusinessDayCounter = new PerformanceCounter(CounterCategoryName, PreviousCounterName, instanceName);
            _previousBusinessDayCounter.ReadOnly = false;
            _previousBusinessDayCounter.RawValue = 0;

            _nextBusinessDayCounter = new PerformanceCounter(CounterCategoryName, NextCounterName, instanceName);
            _nextBusinessDayCounter.ReadOnly = false;
            _nextBusinessDayCounter.RawValue = 0;
        }

        public void IncrementTotalPreviousBusinessDayCalls()
        {
            _previousBusinessDayCounter.Increment();
        }

        public long TotalPreviousBusinessDayCalls
        {
            get 
            {
                return _previousBusinessDayCounter.RawValue;
            }
        }

        public void IncrementTotalNextBusinessDayCalls()
        {
            _nextBusinessDayCounter.Increment();
        }

        public long TotalNextBusinessDayCalls
        {
            get
            { 
                return _nextBusinessDayCounter.RawValue;
            }
        }
    }
}
