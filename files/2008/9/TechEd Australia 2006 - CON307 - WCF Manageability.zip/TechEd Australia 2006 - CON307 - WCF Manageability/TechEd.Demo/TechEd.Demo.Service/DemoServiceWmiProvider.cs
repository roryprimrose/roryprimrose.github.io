using System;
using System.Collections.Generic;
using System.Text;

using System.Management.Instrumentation;

namespace TechEd.Demo.Service
{
    [
        InstrumentationClass(InstrumentationType.Instance)
    ]
    public class DemoServiceWmiProvider : IDemoServiceDataProvider
    {
        private long _totalPreviousBusinessDayCalls = 0;

        public void IncrementTotalPreviousBusinessDayCalls()
        {
            _totalPreviousBusinessDayCalls++;
        }

        public long TotalPreviousBusinessDayCalls
        {
            get
            {
                return _totalPreviousBusinessDayCalls;
            }
        }

        private long _totalNextBusinessDayCalls = 0;

        public void IncrementTotalNextBusinessDayCalls()
        {
            _totalNextBusinessDayCalls++;
        }
        
        public long TotalNextBusinessDayCalls
        {
            get
            {
                return _totalNextBusinessDayCalls;
            }
        }
    }
}
