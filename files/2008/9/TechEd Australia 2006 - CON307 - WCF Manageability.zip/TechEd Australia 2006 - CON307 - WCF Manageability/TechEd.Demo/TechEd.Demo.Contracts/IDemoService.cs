using System;
using System.Collections.Generic;
using System.Text;

using System.ServiceModel;

namespace TechEd.Demo.Contracts
{
    [
        ServiceContract(
            Namespace="http://TechEd/WCF/Demo", 
            Name="DemoService")
    ]
    public interface IDemoService
    {
        [OperationContract]
        DateTime GetServerDate();

        [OperationContract]
        DateTime GetPreviousBusinessDate(DateTime referenceValue);

        [OperationContract]
        DateTime GetNextBusinessDate(DateTime referenceValue);
    }
}
