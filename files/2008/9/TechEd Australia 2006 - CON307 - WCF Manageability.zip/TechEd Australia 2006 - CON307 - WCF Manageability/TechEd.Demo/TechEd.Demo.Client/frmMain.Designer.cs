namespace TechEd.Demo.Client
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label4;
            this.lblCurrent = new System.Windows.Forms.Label();
            this.dtpPrevious = new System.Windows.Forms.DateTimePicker();
            this.lblPrevious = new System.Windows.Forms.Label();
            this.lblNext = new System.Windows.Forms.Label();
            this.dtpNext = new System.Windows.Forms.DateTimePicker();
            this.tmrRefresh = new System.Windows.Forms.Timer(this.components);
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnTimer = new System.Windows.Forms.Button();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(12, 9);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(96, 13);
            label1.TabIndex = 0;
            label1.Text = "Current server day:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(12, 80);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(125, 13);
            label2.TabIndex = 3;
            label2.Text = "Previous business day is:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(12, 151);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(106, 13);
            label4.TabIndex = 6;
            label4.Text = "Next business day is:";
            // 
            // lblCurrent
            // 
            this.lblCurrent.AutoSize = true;
            this.lblCurrent.Location = new System.Drawing.Point(12, 22);
            this.lblCurrent.Name = "lblCurrent";
            this.lblCurrent.Size = new System.Drawing.Size(53, 13);
            this.lblCurrent.TabIndex = 1;
            this.lblCurrent.Text = "Unknown";
            // 
            // dtpPrevious
            // 
            this.dtpPrevious.Location = new System.Drawing.Point(12, 57);
            this.dtpPrevious.Name = "dtpPrevious";
            this.dtpPrevious.Size = new System.Drawing.Size(200, 20);
            this.dtpPrevious.TabIndex = 2;
            this.dtpPrevious.ValueChanged += new System.EventHandler(this.dtpPrevious_ValueChanged);
            // 
            // lblPrevious
            // 
            this.lblPrevious.AutoSize = true;
            this.lblPrevious.Location = new System.Drawing.Point(12, 93);
            this.lblPrevious.Name = "lblPrevious";
            this.lblPrevious.Size = new System.Drawing.Size(53, 13);
            this.lblPrevious.TabIndex = 4;
            this.lblPrevious.Text = "Unknown";
            // 
            // lblNext
            // 
            this.lblNext.AutoSize = true;
            this.lblNext.Location = new System.Drawing.Point(12, 164);
            this.lblNext.Name = "lblNext";
            this.lblNext.Size = new System.Drawing.Size(53, 13);
            this.lblNext.TabIndex = 7;
            this.lblNext.Text = "Unknown";
            // 
            // dtpNext
            // 
            this.dtpNext.Location = new System.Drawing.Point(12, 128);
            this.dtpNext.Name = "dtpNext";
            this.dtpNext.Size = new System.Drawing.Size(200, 20);
            this.dtpNext.TabIndex = 5;
            this.dtpNext.ValueChanged += new System.EventHandler(this.dtpNext_ValueChanged);
            // 
            // tmrRefresh
            // 
            this.tmrRefresh.Tick += new System.EventHandler(this.tmrRefresh_Tick);
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(12, 200);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(75, 23);
            this.btnRefresh.TabIndex = 8;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnTimer
            // 
            this.btnTimer.Location = new System.Drawing.Point(137, 200);
            this.btnTimer.Name = "btnTimer";
            this.btnTimer.Size = new System.Drawing.Size(75, 23);
            this.btnTimer.TabIndex = 9;
            this.btnTimer.Text = "Start";
            this.btnTimer.UseVisualStyleBackColor = true;
            this.btnTimer.Click += new System.EventHandler(this.btnTimer_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(227, 235);
            this.Controls.Add(this.btnTimer);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.lblNext);
            this.Controls.Add(label4);
            this.Controls.Add(this.dtpNext);
            this.Controls.Add(this.lblPrevious);
            this.Controls.Add(label2);
            this.Controls.Add(this.dtpPrevious);
            this.Controls.Add(this.lblCurrent);
            this.Controls.Add(label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.Text = "TechEd WCF Demo";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCurrent;
        private System.Windows.Forms.DateTimePicker dtpPrevious;
        private System.Windows.Forms.Label lblPrevious;
        private System.Windows.Forms.Label lblNext;
        private System.Windows.Forms.DateTimePicker dtpNext;
        private System.Windows.Forms.Timer tmrRefresh;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnTimer;
    }
}

