using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.ServiceModel;

using TechEd.Demo.Contracts;

namespace TechEd.Demo.Client
{
    public partial class frmMain : Form
    {
        #region Demo template code
        
        public frmMain()
        {
            InitializeComponent();
        }

        private void btnTimer_Click(object sender, EventArgs e)
        {
            if (btnTimer.Text == "Start")
            {
                btnTimer.Text = "Stop";
                tmrRefresh.Enabled = true;
            }
            else
            {
                btnTimer.Text = "Start";
                tmrRefresh.Enabled = false;
            }
        }

        private void dtpPrevious_ValueChanged(object sender, EventArgs e)
        {
            SetPreviousDay();
        }

        private void dtpNext_ValueChanged(object sender, EventArgs e)
        {
            SetNextDay();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            RefreshAll();
        }

        private void tmrRefresh_Tick(object sender, EventArgs e)
        {
            RefreshAll();
        }

        private void RefreshAll()
        {
            SetCurrentDay();
            SetNextDay();
            SetPreviousDay();
        }

        #endregion

        private IDemoService demoService = null;

        private void frmMain_Load(object sender, EventArgs e)
        {
            demoService = new ChannelFactory<IDemoService>("DemoService").CreateChannel();

            RefreshAll();
        }

        private void SetCurrentDay()
        {
            lblCurrent.Text = demoService.GetServerDate().ToString();
        }

        private void SetPreviousDay()
        {
            lblPrevious.Text = demoService.GetPreviousBusinessDate(dtpPrevious.Value).ToString();
        }

        private void SetNextDay()
        {
            lblNext.Text = demoService.GetNextBusinessDate(dtpNext.Value).ToString();
        }
    }
}