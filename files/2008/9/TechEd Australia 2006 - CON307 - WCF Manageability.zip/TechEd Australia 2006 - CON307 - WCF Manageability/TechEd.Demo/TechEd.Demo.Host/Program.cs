using System;
using System.Collections.Generic;
using System.Text;

using System.Configuration;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Configuration;

using TechEd.Demo.Service;

namespace TechEd.Demo.Host
{
    class Program
    {
        static void Main(string[] args)
        {
            Type serviceType = typeof(DemoService);

            // Load the service config
            ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
            fileMap.ExeConfigFilename = AppDomain.CurrentDomain.SetupInformation.ConfigurationFile;
            Configuration appConfig = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
            ServiceModelSectionGroup serviceModel = ServiceModelSectionGroup.GetSectionGroup(appConfig);
            ServiceElement serviceConfig = serviceModel.Services.Services[serviceType.FullName];
            ServiceEndpointElement serviceEndPointConfig = serviceConfig.Endpoints[0];

            // TODO: Creating performance counter category

            // TODO: Creating service

            Console.WriteLine("Creating service host");
            using (ServiceHost host
                = new ServiceHost(serviceType,
                    new Uri[] { serviceEndPointConfig.Address }))
            {
                // TODO: Creating performance counters

                Console.WriteLine("Opening the service host");
                host.Open();

                Console.WriteLine("The service is available");
                Console.ReadKey();
            }

            // TODO: Destroying performance counter category
        }
    }
}
